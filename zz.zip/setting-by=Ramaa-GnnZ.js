const chalk = require("chalk")
const fs = require("fs")



//DATA AKUN ORDER KOUTA
//WAJIB DI ISI
global.usn = "zhulant"//username orkut (contoh: "ramagnnz")
global.token = "2356910:2ldjeBFCuGUv5L3S7OgxrJipZ6XM9mTQ"// DAPETIN TOKEN TANYA KE DEVELOPER (Ramaa GnnZ) //085791220179
global.idOrkut = "OK2356910" //ganti dengan id orkut kamu
global.pwOrkut = "Zhuwi17072016@@" //ganti dengan pw orkut kamu
const pinOrkut = "1590" //ganti dengan pin orkut kamu
const apiOrkut = "242803817442967512356910OKCT3E933F3964952F404B7634EF41A940FA" //isi dengan apikey orkut kamu 
global.qris_string = "00020101021126670016COM.NOBUBANK.WWW01189360050300000879140214502386517724540303UMI51440014ID.CO.QRIS.WWW0215ID20253900625400303UMI5204541153033605802ID5921ZHUWI STORE OK23569106006KEDIRI61056411162070703A0163045FE3" //isi dengan code qris kamu


//SETTINGAN TOPUP
global.untung = "3"
  //Ini profit yg kamu dapat, 2 = 2% maka harga akan meningkat 1%
  //Isi sesuai kebutuhan 
  global.batas_waktu_deposit = "15m" //batas expired payment deposit
  global.batas_waktu_pay_topup = "5m" //batas expired payment Topup 
  //15m = 15 menit, ganti sesuai kebutuhan wajib dibelakang ada huruf m
  
  
//===== SETTINGAN BOT
  global.ownerNumber = "6285336393488@s.whatsapp.net"
  global.kontakOwner = "6285336393488"
  global.namaStore = "ZhuWi Store"
  global.botName = "ZhuWi Store"
  global.ownerName = "ZhuL"
  
  
  //=== SOSIAL MEDIA
  global.linkgc1 = "https://chat.whatsapp.com/FSpZWiEd5TBLKObSTLXlrQ"
  global.linkgc2 = "https://chat.whatsapp.com/HtEECgOgX9L92WFAYe1nL7"
  global.linkyt = "-"
  global.linkig = "-"
  global.sawer = "-"


//PAYMENT 
const payment = {
    dana: {
      nomer: "085336393488",
      atas_nama: "YUL****"
    }
}
global.dana = "085336393488"
global.ovo = "085336393488"
global.gopay = "081932233344"
// kalau gada, isi dengan "--"



//==============================================
let file = require.resolve(__filename)
fs.watchFile(file, () => {
	fs.unwatchFile(file)
	console.log(chalk.redBright(`Update'${__filename}'`))
	delete require.cache[file]
	require(file)
})
module.exports = { payment, idOrkut, pwOrkut, pinOrkut, apiOrkut }