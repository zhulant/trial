//Mohon Untuk Tidak Menjual Script ini 

require('./setting-by=Ramaa-GnnZ')
const { BufferJSON, WA_DEFAULT_EPHEMERAL, proto, prepareWAMessageMedia, areJidsSameUser, getContentType } = require('@whiskeysockets/baileys')
const { getAggregateVotesInPollMessage, downloadContentFromMessage, generateWAMessage, generateWAMessageFromContent, MessageType, buttonsMessage } = require("@whiskeysockets/baileys")
const { exec, spawn } = require("child_process");
const { color, bgcolor, pickRandom, randomNomor } = require('./lib/console.js')
const { isUrl, getRandom, getGroupAdmins, runtime, sleep, reSize, makeid, fetchJson, getBuffer } = require("./lib/myfunc");
const { addResponList, delResponList, isAlreadyResponList, isAlreadyResponListGroup, sendResponList, updateResponList, getDataResponList } = require('./lib/addlist');
const { addResponTesti, delResponTesti, isAlreadyResponTesti, sendResponTesti, updateResponTesti, getDataResponTesti } = require('./lib/respon-testi');
const { addResponProduk, delResponProduk, resetProdukAll, isAlreadyResponProduk, sendResponProduk, updateResponProduk, getDataResponProduk } = require('./lib/respon-produk');
// apinya
const fs = require("fs");
const chalk = require('chalk');
const axios = require("axios");
const speed = require("performance-now");
const colors = require('colors/safe');
const ffmpeg = require("fluent-ffmpeg");
const moment = require("moment-timezone");
const { UploadFileUgu } = require('./lib/Upload_Url');
const fetch = require('node-fetch');
const jimp = require('jimp')
const qs = require("qs");
const toMs = require('ms');
const ms = require('parse-ms');
const QRCode = require('qrcode');
const { qrisDinamis } = require("./lib/dinamis");
const { createCanvas, loadImage } = require('canvas');

// Database
const antilink = JSON.parse(fs.readFileSync('./database/antilink.json'));
const antilink2 = JSON.parse(fs.readFileSync('./database/antilink2.json'));
const mess = JSON.parse(fs.readFileSync('./mess.json'));
const welcome = JSON.parse(fs.readFileSync('./database/welcome.json'));
const db_error = JSON.parse(fs.readFileSync('./database/error.json'));
const db_respon_list = JSON.parse(fs.readFileSync('./database/list.json'));
const db_respon_testi = JSON.parse(fs.readFileSync('./database/list-testi.json'));
const db_respon_produk = JSON.parse(fs.readFileSync('./database/list-produk.json'));
const { addSaldo, minSaldo, cekSaldo } = require("./lib/deposit");
let db_saldo = JSON.parse(fs.readFileSync("./database/saldo.json"));
const {payment, idOrkut, pwOrkut, pinOrkut, apiOrkut } = require("./setting-by=Ramaa-GnnZ")
let depositPath = "./database/deposit/"
let topupPath = "./database/topup/"
const OrderKuota = require('./lib/orderkuota');
const order = new OrderKuota();

moment.tz.setDefault("Asia/Jakarta").locale("id");
module.exports = async(ramz, msg, m, setting, store) => {
try {
const { type, quotedMsg, mentioned, now, fromMe, isBaileys } = msg
if (msg.isBaileys) return
try {
            if (!global._recentMsgs) global._recentMsgs = new Map()
            const procKey = `${msg.key.remoteJid || ''}|${msg.key.id || ''}|${msg.key.participant || ''}`
            if (global._recentMsgs.has(procKey)) return
            global._recentMsgs.set(procKey, Date.now())
            // auto-clear after 30s
            setTimeout(() => { try { global._recentMsgs.delete(procKey) } catch (e) { } }, 30 * 1000)
        } catch (e) { }
const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
const tanggal = moment().tz("Asia/Jakarta").format("ll")
let dt = moment(Date.now()).tz('Asia/Jakarta').locale('id').format('a')
const ucapanWaktu = "Selamat "+dt.charAt(0).toUpperCase() + dt.slice(1)
const content = JSON.stringify(msg.message)
const from = msg.key.remoteJid
const time = moment(new Date()).format("HH:mm");
var chats = (type === 'conversation' && msg.message.conversation) ? msg.message.conversation : (type === 'imageMessage') && msg.message.imageMessage.caption ? msg.message.imageMessage.caption : (type === 'videoMessage') && msg.message.videoMessage.caption ? msg.message.videoMessage.caption : (type === 'extendedTextMessage') && msg.message.extendedTextMessage.text ? msg.message.extendedTextMessage.text : (type === 'buttonsResponseMessage') && quotedMsg.fromMe && msg.message.buttonsResponseMessage.selectedButtonId ? msg.message.buttonsResponseMessage.selectedButtonId : (type === 'templateButtonReplyMessage') && quotedMsg.fromMe && msg.message.templateButtonReplyMessage.selectedId ? msg.message.templateButtonReplyMessage.selectedId : (type === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId) : (type == 'listResponseMessage') && quotedMsg.fromMe && msg.message.listResponseMessage.singleSelectReply.selectedRowId ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : ""
if (chats == undefined) { chats = '' }
global.prefa = ['','.']
const prefix = prefa ? /^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi.test(chats) ? chats.match(/^[°•π÷×¶∆£¢€¥®=????+✓_=|~!?@#%^&.©^]/gi)[0] : "" : prefa ?? global.prefix
const isGroup = msg.key.remoteJid.endsWith('@g.us')
const sender = isGroup ? (msg.key.participant ? msg.key.participant : msg.participant) : msg.key.remoteJid
const isOwner = [`${global.ownerNumber}`,"6285791220179@s.whatsapp.net","6285806240904@s.whatsapp.net"].includes(sender) ? true : false
const pushname = msg.pushName
const body = chats.startsWith(prefix) ? chats : ''
const budy = (type === 'conversation') ? msg.message.conversation : (type === 'extendedTextMessage') ? msg.message.extendedTextMessage.text : ''
const args = body.trim().split(/ +/).slice(1);
const q = args.join(" ");
const isCommand = chats.startsWith(prefix);
const command = chats.replace(prefix, '').trim().split(/ +/).shift().toLowerCase()
const isCmd = isCommand ? chats.slice(1).trim().split(/ +/).shift().toLowerCase() : null;
const botNumber = ramz.user.id.split(':')[0] + '@s.whatsapp.net'
const toJSON = j => JSON.stringify(j, null,'\t')

// Group
const groupMetadata = msg.isGroup ? await ramz.groupMetadata(from).catch(() => {}) : ''
const groupName = msg.isGroup ? (groupMetadata && groupMetadata.subject) : ''
const groupId = isGroup ? groupMetadata.id : ''
const participants = msg.isGroup ? groupMetadata.participants : []
const groupMembers = isGroup ? groupMetadata.participants : ''
const groupAdmins = participants
    .filter(p => p.admin === 'superadmin' || p.admin === 'admin')
    .map(p => p.jid)
const isBotGroupAdmins = groupAdmins.includes(botNumber) || false
const isGroupAdmins = groupAdmins.includes(sender)
const isAntiLink = antilink.includes(from) ? true : false
const isAntiLink2 = antilink.includes(from) ? true : false
const isWelcome = isGroup ? welcome.includes(from) : false
function TelegraPh(path) {
    return new Promise(async (resolve, reject) => {
	const { ImageUploadService } = require('node-upload-images')
const service = new ImageUploadService('pixhost.to');
    try {
let { directLink } = await service.uploadFromBinary(fs.readFileSync(path), 'ramagnz.jpg');
let teks = directLink.toString()
			return resolve(teks)
		} catch (err) {
			return reject(new Error(String(err)))
		}
        })
    }
// Quoted
const quoted = msg.quoted ? msg.quoted : msg
const isImage = (type == 'imageMessage')
const isQuotedMsg = (type == 'extendedTextMessage')
const isMedia = (type === 'imageMessage' || type === 'videoMessage');
const isQuotedImage = isQuotedMsg ? content.includes('imageMessage') ? true : false : false
const isVideo = (type == 'videoMessage')
const isQuotedVideo = isQuotedMsg ? content.includes('videoMessage') ? true : false : false
const isSticker = (type == 'stickerMessage')
const isQuotedSticker = isQuotedMsg ? content.includes('stickerMessage') ? true : false : false 
const isQuotedAudio = isQuotedMsg ? content.includes('audioMessage') ? true : false : false
var dataGroup = (type === 'buttonsResponseMessage') ? msg.message.buttonsResponseMessage.selectedButtonId : ''
var dataPrivate = (type === "messageContextInfo") ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId) : ''
const isButton = dataGroup.length !== 0 ? dataGroup : dataPrivate
var dataListG = (type === "listResponseMessage") ? msg.message.listResponseMessage.singleSelectReply.selectedRowId : ''
var dataList = (type === 'messageContextInfo') ? (msg.message.buttonsResponseMessage?.selectedButtonId || msg.message.listResponseMessage?.singleSelectReply.selectedRowId) : ''
const isListMessage = dataListG.length !== 0 ? dataListG : dataList

function mentions(teks, mems = [], id) {
if (id == null || id == undefined || id == false) {
let res = ramz.sendMessage(from, { text: teks, mentions: mems })
return res
} else {
let res = ramz.sendMessage(from, { text: teks, mentions: mems }, { quoted: msg })
return res
}
}
// ===== FILTER SENDER (PRIVATE ONLY) =====
if (!isGroup) {
  //  const sender = msg.key?.participant || msg.key?.remoteJid

    // HENTIKAN jika sender kosong
    if (!sender) return

    // HENTIKAN jika sender LID (Linked Device)
    if (sender.endsWith("@lid")) return
}

if (msg.message) {
	if (!pushname) return
	}


const mentionByTag = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.mentionedJid : []
const mentionByReply = type == "extendedTextMessage" && msg.message.extendedTextMessage.contextInfo != null ? msg.message.extendedTextMessage.contextInfo.participant || "" : ""
const mention = typeof(mentionByTag) == 'string' ? [mentionByTag] : mentionByTag
mention != undefined ? mention.push(mentionByReply) : []
const mentionUser = mention != undefined ? mention.filter(n => n) : []

async function downloadAndSaveMediaMessage (type_file, path_file) {
if (type_file === 'image') {
var stream = await downloadContentFromMessage(msg.message.imageMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.imageMessage, 'image')
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk]) }
fs.writeFileSync(path_file, buffer)
return path_file } 
else if (type_file === 'video') {
var stream = await downloadContentFromMessage(msg.message.videoMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.videoMessage, 'video')
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
fs.writeFileSync(path_file, buffer)
return path_file
} else if (type_file === 'sticker') {
var stream = await downloadContentFromMessage(msg.message.stickerMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.stickerMessage, 'sticker')
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
fs.writeFileSync(path_file, buffer)
return path_file
} else if (type_file === 'audio') {
var stream = await downloadContentFromMessage(msg.message.audioMessage || msg.message.extendedTextMessage?.contextInfo.quotedMessage.audioMessage, 'audio')
let buffer = Buffer.from([])
for await(const chunk of stream) {
buffer = Buffer.concat([buffer, chunk])}
fs.writeFileSync(path_file, buffer)
return path_file}
}

function toRupiah(angka) {
var saldo = '';
var angkarev = angka.toString().split('').reverse().join('');
for (var i = 0; i < angkarev.length; i++)
if (i % 3 == 0) saldo += angkarev.substr(i, 3) + '.';
return '' + saldo.split('', saldo.length - 1).reverse().join('');
}

function randomNomor(min, max = null) {
if (max !== null) {
min = Math.ceil(min);
max = Math.floor(max);
return Math.floor(Math.random() * (max - min + 1)) + min;
} else {
return Math.floor(Math.random() * min) + 1
}
}

const reply = (teks) => {ramz.sendMessage(from, { text: teks }, { quoted: msg })}

//Antilink
if (isGroup && isAntiLink && isBotGroupAdmins){
if (chats.includes(`https://chat.whatsapp.com/`) || chats.includes(`http://chat.whatsapp.com/`)) {
if (!isBotGroupAdmins) return reply('Untung bot bukan admin')
if (isOwner) return reply('Untung lu owner ku:v😙')
if (isGroupAdmins) return reply('Admin grup mah bebas ygy🤭')
if (fromMe) return reply('bot bebas Share link')
await ramz.sendMessage(from, { delete: msg.key })
reply(`*「 GROUP LINK DETECTOR 」*\n\nTerdeteksi mengirim link group,Maaf sepertinya kamu akan di kick`)
ramz.groupParticipantsUpdate(from, [sender], "remove")
}
}

//Antilink 2
if (isGroup && isAntiLink2 && isBotGroupAdmins){
if (chats.includes(`https://chat.whatsapp.com/`) || chats.includes(`http://chat.whatsapp.com/`)) {
if (!isBotGroupAdmins) return reply('Untung bot bukan admin')
if (isOwner) return reply('Untung lu owner ku:v😙')
if (isGroupAdmins) return reply('Admin grup mah bebas ygy🤭')
if (fromMe) return reply('bot bebas Share link')
await ramz.sendMessage(from, { delete: msg.key })
reply(`*「 GROUP LINK DETECTOR 」*\n\nTerdeteksi mengirim link group,Maaf sepertinya kamu akan di kick`)
}
}

// Response Addlist
if (isGroup && isAlreadyResponList(from, chats, db_respon_list)) {
var get_data_respon = getDataResponList(from, chats, db_respon_list)
if (get_data_respon.isImage === false) {
ramz.sendMessage(from, { text: sendResponList(from, chats, db_respon_list) }, {
quoted: msg
})
} else {
ramz.sendMessage(from, { image: await getBuffer(get_data_respon.image_url), caption: get_data_respon.response }, {quoted: msg})
}
}
if (!isGroup && isAlreadyResponTesti(chats, db_respon_testi)) {
var get_data_respon = getDataResponTesti(chats, db_respon_testi)
ramz.sendMessage(from, { image: { url: get_data_respon.image_url }, caption: get_data_respon.response }, { quoted: msg })
}
if (!isGroup && isAlreadyResponProduk(chats, db_respon_produk)) {
var get_data_respon = getDataResponProduk(chats, db_respon_produk)
ramz.sendMessage(from, { image: { url: get_data_respon.image_url }, caption: get_data_respon.response }, { quoted: msg })
}

const sendContact = (jid, numbers, name, quoted, mn) => {
let number = numbers.replace(/[^0-9]/g, '')
const vcard = 'BEGIN:VCARD\n' 
+ 'VERSION:3.0\n' 
+ 'FN:' + name + '\n'
+ 'ORG:;\n'
+ 'TEL;type=CELL;type=VOICE;waid=' + number + ':+' + number + '\n'
+ 'END:VCARD'
return ramz.sendMessage(from, { contacts: { displayName: name, contacts: [{ vcard }] }, mentions : mn ? mn : []},{ quoted: quoted })
}


const fkontak = { key: {fromMe: false,participant: `0@s.whatsapp.net`, ...(from ? { remoteJid: "status@broadcast" } : {}) }, message: { 'contactMessage': { 'displayName': `Bot Created By ${global.ownerName}\n`, 'vcard': `BEGIN:VCARD\nVERSION:3.0\nN:XL;${global.botName},;;;\nFN:Halo ${pushname},\nitem1.TEL;waid=${sender.split('@')[0]}:${sender.split('@')[0]}\nitem1.X-ABLabel:Ponsel\nEND:VCARD`, 'jpegThumbnail': { url: `${global.qris}` }}}}
function parseMention(text = '') {
return [...text.matchAll(/@([0-9]{5,16}|0)/g)].map(v => v[1] + '@s.whatsapp.net')
}

function digit() {
      const characters = '0123456789';
      const length = 2;
      let haha = '';
      for (let i = 0; i < length; i++) {
        const randomIndex = Math.floor(Math.random() * characters.length);
        haha += characters[randomIndex];
      }
      return haha;
    }
    
async function generateImage(namaUtama, idTrx, nameP, SN) {
    	const canvasWidth = 800;
    const canvasHeight = 600;
    const canvas = createCanvas(canvasWidth, canvasHeight);
    const ctx = canvas.getContext('2d');
    
        try {
            // Input gambar latar belakang
            const backgroundImage = await loadImage('https://img12.pixhost.to/images/649/572422759_ramagnz.jpg');
            ctx.drawImage(backgroundImage, 0, 0, canvasWidth, canvasHeight);

            // Input logo bulat di pojok kiri atas
            const logoImage = await loadImage(fs.readFileSync(`./gambar/logo.jpg`));
            const logoSize = 100; // Ukuran logo
            ctx.save();
            ctx.beginPath();
            ctx.arc(logoSize / 2, logoSize / 2, logoSize / 2, 0, Math.PI * 2, true);
            ctx.closePath();
            ctx.clip();
            ctx.drawImage(logoImage, 0, 0, logoSize, logoSize);
            ctx.restore();

            // Tambahkan stroke putih pada logo
            ctx.beginPath();
            ctx.arc(logoSize / 2, logoSize / 2, logoSize / 2, 0, Math.PI * 2);
            ctx.lineWidth = 5;
            ctx.strokeStyle = 'white';
            ctx.stroke();

             // Nama utama dengan motif awan di belakang
            const mainNameFontSize = 50;
            ctx.font = `bold ${mainNameFontSize}px Arial`;
            ctx.textAlign = 'center';
            ctx.textBaseline = 'middle';

            const mainNameX = canvas.width / 2;
            const mainNameY = canvas.height / 4;

            // Tambahkan motif awan di belakang teks
            ctx.save();
            ctx.translate(mainNameX, mainNameY);
            ctx.beginPath();
            ctx.moveTo(-150, 0);
            ctx.bezierCurveTo(-200, -50, -100, -50, -150, 0);
            ctx.bezierCurveTo(-50, 50, 50, 50, 150, 0);
            ctx.bezierCurveTo(100, -50, 200, -50, 150, 0);
            ctx.closePath();
            ctx.fillStyle = 'rgba(255, 255, 255, 0.5)';
            ctx.fill();
            ctx.restore();

            // Gambar stroke untuk nama utama
            ctx.lineWidth = 8;
            ctx.strokeStyle = '#00B0C9';
            ctx.strokeText(namaUtama, mainNameX, mainNameY);

            // Gambar nama utama
            ctx.fillStyle = 'white';
            ctx.fillText(namaUtama, mainNameX, mainNameY);

            // Tiga teks di bawahnya
            ctx.font = 'bold 20px Qlassik';
            ctx.textAlign = 'center';
            ctx.fillStyle = 'white';
            ctx.fillText(idTrx, canvasWidth / 1.5, 250);
            ctx.fillText(nameP, canvasWidth / 1.5, 320);

            // Teks ketiga, otomatis memotong baris jika terlalu panjang
            const thirdText = SN;
        const maxCharsPerLine = 30; // Maksimal karakter per baris
        const lineHeight = 24;
        let startY = 390;

        // Gambar teks ketiga dengan pemotongan
        for (let i = 0; i < thirdText.length; i += maxCharsPerLine) {
            const line = thirdText.slice(i, i + maxCharsPerLine);
            ctx.fillText(line.trim(), canvasWidth / 1.7, startY); // Menggambar baris teks
            startY += lineHeight; // Geser ke bawah untuk baris berikutnya
        }
            // Teks tanggal dan jam
            const dateTimeText = `${tanggal} - ${jam} WIB`;
            ctx.font = '20px Arial';
            const textWidth = ctx.measureText(dateTimeText).width;
            const textHeight = 20; // Estimasi tinggi teks
            const padding = 10;
            const rectX = (canvasWidth - textWidth) / 2 - padding;
            const rectY = canvasHeight - 40;
            const rectWidth = textWidth + padding * 2;
            const rectHeight = textHeight + padding * 2;

            // Gambar kotak hitam
          //  ctx.fillStyle = '#17536A';
       //     ctx.fillRect(rectX, rectY, rectWidth, rectHeight);

            // Gambar teks tanggal dan jam
            ctx.textAlign = 'center';
            ctx.fillStyle = 'white';
            ctx.fillText(dateTimeText, canvasWidth / 2, canvasHeight - 20);

 
              const media = `./gambar/invoice.jpg`
            const out = fs.createWriteStream(media);
            const stream = canvas.createPNGStream();
            stream.pipe(out);
            out.on('finish', () => console.log('Image sukses'));
        } catch (error) {
            console.error('Terjadi kesalahan:', error);
        }
    }
if (isListMessage === "payqris") {
if (!fs.existsSync(depositPath + sender.split("@")[0] + ".json")) {
var deposit_object = {
ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
session: "amount",
date: new Date().toLocaleDateString("ID", { timeZone: "Asia/Jakarta"}),
number: sender,
payment: "QRIS",
data: {
iddepo: "",
exp: "",
amount_deposit: "",
pajak: "",
total_deposit: ""
}
}
fs.writeFileSync(depositPath + sender.split("@")[0] + ".json", JSON.stringify(deposit_object, null, 2))
reply("Oke kak mau deposit berapa?\n\nContoh: 15000")
} else {
reply("Proses Deposit kamu masih ada yang belum terselesaikan\n\nKetik Batal untuk membatalkan")
}
} else if (isListMessage === "paydana") {
if (!fs.existsSync(depositPath + sender.split("@")[0] + ".json")) {
var deposit_object = {
ID: require("crypto").randomBytes(5).toString("hex").toUpperCase(),
session: "amount",
date: new Date().toLocaleDateString("ID", { timeZone: "Asia/Jakarta"}),
number: sender,
payment: "DANA",
data: {
amount_deposit: ""
}
}
fs.writeFileSync(depositPath + sender.split("@")[0] + ".json", JSON.stringify(deposit_object, null, 2))
reply("Oke kak mau deposit berapa?\n\nContoh: 15000")
} else {
reply("Proses Deposit kamu masih ada yang belum terselesaikan\n\nKetik Batal untuk membatalkan")
}
}

if (fs.existsSync(depositPath + sender.split("@")[0] + ".json")) {
if (!msg.key.fromMe) {
let data_deposit = JSON.parse(fs.readFileSync(depositPath + sender.split("@")[0] + ".json"))
if (data_deposit.session === "amount") {
if (isNaN(chats)) return reply("Masukan hanya angka ya")
data_deposit.data.amount_deposit = Number(chats)
if (data_deposit.data.amount_deposit < 2000) return reply(`Deposit Minimal Rp2000`)
if (data_deposit.data.amount_deposit > 5000000) return reply(`Nominal Deposit terlalu tinggi`)
data_deposit.session = "konfirmasi_deposit";
fs.writeFileSync(depositPath + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 3));
if (data_deposit.payment === "QRIS") {
let pajakny = (0.01 / 100) * data_deposit.data.amount_deposit
          let pajak2 = Number(Math.ceil(pajakny)) + digit()
data_deposit.data.total_deposit = Number(chats) + Number(pajak2)
data_deposit.data.pajak = Number(pajak2)
fs.writeFileSync(depositPath + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 3));
ramz.sendMessage(from, { text: `「 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄-𝘿𝙀𝙋𝙊𝙎𝙄𝙏 」

▪ ID: ${data_deposit.ID}
▪ Number: ${data_deposit.number.split('@')[0]}
▪ Payment: ${data_deposit.payment}
▪ Jumlah Deposit: Rp${toRupiah(data_deposit.data.amount_deposit)}
▪ Pajak Admin: Rp${toRupiah(Number(pajak2))}
▪ Total Pembayaran: Rp${toRupiah(data_deposit.data.total_deposit)}

_Ketik *lanjut* untuk melanjutkan_
_Ketik *batal* untuk membatalkan_` }, { quoted: msg })
} else {
ramz.sendMessage(from, {text: `「 𝙆𝙊𝙉𝙁𝙄𝙍𝙈𝘼𝙎𝙄-𝘿𝙀𝙋𝙊𝙎𝙄𝙏 」

▪ ID : ${data_deposit.ID}
▪ Nomer : ${data_deposit.number.split('@')[0]}
▪ Payment : ${data_deposit.payment}
▪ Jumlah Deposit : Rp${toRupiah(data_deposit.data.amount_deposit)}
▪ Pajak Admin : Rp0
▪ Total Pembayaran : Rp${toRupiah(data_deposit.data.amount_deposit)}

_Ketik Lanjut untuk melanjutkan_
_Ketik Batal untuk membatalkan_`}, { quoted: msg })
}
} else if (data_deposit.session === "konfirmasi_deposit") {
if (chats.toLowerCase() === "lanjut") {
 if (data_deposit.payment === "QRIS") {
 	let pay = await qrisDinamis(`${data_deposit.data.total_deposit}`, "./gambar/qris_depo.jpg")

              let time = Date.now() + toMs(global.batas_waktu_deposit);
              let expirationTime = new Date(time);
              let timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
              let currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
              let expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
              let hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
              let minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
              let formattedTime = `${hours}:${minutes}`
data_deposit.data.exp = time;
fs.writeFileSync(depositPath + sender.split("@")[0] + ".json", JSON.stringify(data_deposit, null, 3));
await sleep(2000)
var qr_fexf =`━━[ *PAYMENT QRIS* ]━━

*▪ID:* ${data_deposit.ID}
*▪Nomer:* ${data_deposit.number.split("@")[0]}
*▪Jumlah Deposit:* Rp${toRupiah(data_deposit.data.amount_deposit)}
*▪Pajak Admin:* Rp${toRupiah(data_deposit.data.pajak)}
*▪Total Pembayaran:* Rp${toRupiah(data_deposit.data.total_deposit)}
*▪Batas Waktu:* ${timeLeft} MENIT
*▪Expired:* ${formattedTime} WIB

_Silahkan scan QRIS diatas, ketik batal untuk membatalkan_`
let payy = await ramz.sendMessage(from, { image: fs.readFileSync(pay), caption: qr_fexf }, { quoted: msg })
while (fs.existsSync(depositPath + sender.split("@")[0] + ".json")) {
await sleep(13000)
if (Date.now() >= data_deposit.data.exp) {
                  await ramz.sendMessage(from, { delete: payy.key })
                  reply("Deposit anda telah melewati batas waktu⌛")
                  fs.unlinkSync(depositPath + sender.split('@')[0] + '.json')
                }
                try {
                  const ok = new OrderKuota(global.usn, global.token);
                        let response = await ok.getQRISHistory("qris_history");
                        let results = response?.qris_history?.results || [];

                        const toleransi = 0;
                        const amountInt = parseInt(data_deposit.data.total_deposit); // 49321

                        let result = results.find(x => {
                            let kreditClean = Number(x.kredit.replace('.', '')); // "49.321" → 49321
                            return Math.abs(kreditClean - amountInt) <= toleransi;
                        });

                        console.log("Ditemukan:", result);
if (result) {
                    await ramz.sendMessage(from, { delete: payy.key })
                    let text_sukses = `*DEPOSIT SUKSES*
• ID: ${data_deposit.ID}
• Nomer: @${data_deposit.number.split('@')[0]}
• Payment: ${data_deposit.payment}
• Tanggal: ${tanggal}
• Jumlah Deposit: Rp${toRupiah(data_deposit.data.amount_deposit)}
• Pajak: Rp${toRupiah(data_deposit.data.pajak)}
• Total Bayar: Rp${toRupiah(data_deposit.data.total_deposit)}`
                    await ramz.sendMessage(from, { text: `${text_sukses}\n\nKetik _Saldo_ untuk cek saldo anda`, mentions: [sender]}, { quoted: msg })
                    await ramz.sendMessage(`${global.ownerNumber}`, { text: `Ada yang deposit dari @${data_deposit.number.split('@')[0]}, silahkan cairkan saldo di qris order kouta anda agar bisa digunakan untuk topup`, mentions: [sender] })
                    addSaldo(sender, Number(data_deposit.data.amount_deposit), db_saldo)
fs.unlinkSync(depositPath + sender.split("@")[0] + ".json")
                  }
                } catch (error) {
                  reply("Deposit dibatalkan Dikarenakan ada kendala pada sistem\nSilahkan deposit ulang ")
                  console.log("----Eror---:", error);
                  fs.unlinkSync(depositPath + sender.split("@")[0] + ".json")
                }
              }
              
} else if (data_deposit.payment === "DANA") {
var py_dana =`༆━━[ *PAYMENT DANA* ]━━࿐
 
*Nomer :* ${payment.dana.nomer}
*AN :* ${payment.dana.atas_nama}

_Silahkan transfer dengan nomor yang sudah tertera, Jika sudah harap kirim bukti foto dengan caption #bukti untuk di acc oleh admin_`
reply(py_dana)
}} else if (chats.toLowerCase() === "batal") {
let data_deposit = JSON.parse(fs.readFileSync(depositPath + sender.split("@")[0] + ".json"))
reply(`Baik kak, deposit dengan ID: ${data_deposit.ID} dibatalkan`)
fs.unlinkSync(depositPath + sender.split('@')[0] + '.json')
}}}}


if (fs.existsSync(topupPath + sender.split("@")[0] + ".json")) {
	if (!msg.key.fromMe) {
		
let data_topup = JSON.parse(fs.readFileSync(topupPath + sender.split("@")[0] + ".json"))
 if (data_topup.session === "target") {
	if (fromMe) return
if (data_topup.data.code.includes("PB")) {
    if (!chats || chats.length > 20) return reply("Maksimal 20 karakter diperbolehkan.");
} else {
    if (!chats || isNaN(chats)) return reply("Hanya Masukan Nomor/Id. Tidak boleh ada karakter lain.");
}
data_topup.data.target = chats.trim();
data_topup.session = "konfirmasi_topup";
fs.writeFileSync(topupPath + sender.split("@")[0] + ".json", JSON.stringify(data_topup, null, 3));
ramz.sendMessage(from,
{text: `*TARGET:* ${data_topup.data.target}\nPastikan ID/Nomor yg anda masukan benar`,
buttonText: "Tekan Disini",
sections: [{title: "Pilih Lanjut/Batal",
rows: [
{title: "Lanjut", rowId: "lanjutt", description: "Lanjut untuk Melanjutkan Transaksi"},
{title: "Batal", rowId: "batal", description: "Batal Untuk membatalkan Transaksi"}]}
]})
} else if (data_topup.session === "konfirmasi_topup") {
	if (isListMessage === "lanjutt") {
	var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};

axios.get(`https://b2b.okeconnect.com/trx-v2?product=${data_topup.data.code}&dest=${data_topup.data.target}&refID=${data_topup.data.id}&memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}`)
.then(response => response.data)
.then(async res=> {
	console.log(res)
//if (res.status === "GAGAL") {
   // fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
  // let message = `*PESANAN GAGAL❌*`;
 // if (data_topup.pay === "yes") {
     // addSaldo(sender, data_topup.data.price, db_saldo);
   // message = `*PESANAN GAGAL❌*\nSaldo Anda otomatis bertambah dan langsung bisa digunakan untuk topup kembali.\nSilahkan ketik _#saldo_ untuk melihat saldo Anda.`;
   // }
  //return reply(message);
//}
	let persen = (untung / 100) * data_topup.data.price
	data_topup.result = "proses"
	fs.writeFileSync(topupPath + sender.split("@")[0] + ".json", JSON.stringify(data_topup, null, 3));
	reply(`*「 BERHASIL DI PROSES 」*\n\nYeayy, pesanan anda telah di proses oleh bot silahkan tunggu sejenak`)
})
await sleep(2000)
var intervals = setInterval(function() {
var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};
fetch(`https://b2b.okeconnect.com/trx-v2?memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}&product=${data_topup.data.code}&dest=${data_topup.data.target}&refID=${data_topup.data.id}`, requestOptions)
.then(responsep => responsep.json())
.then(async resss => {
console.log(resss); // For Debugging
console.log(color("[TRANSAKSI]", "green"), `-> ${sender}`) // For Debugging
if (resss.status === "SUKSES") {
  generateImage(`${global.namaStore}`, `${data_topup.data.id}`, `${data_topup.data.layanan}`, `${resss.sn}`);
    fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
if (data_topup.pay === "no" ) {
minSaldo(sender, data_topup.data.price, db_saldo)
}
await sleep(2500)
    ramz.sendMessage(from, { image: fs.readFileSync(`./gambar/invoice.jpg`), caption: `*「  TOPUP SUKSES  」*\n*⌬ Status:* Suksess\n*⌬ ID Order:* ${data_topup.data.id}\n*⌬ Layanan:* ${data_topup.data.layanan}\n*⌬ Nomor Tujuan:* ${data_topup.data.target}\n*⌬ Price:* Rp${toRupiah(data_topup.data.price)}\n\n*⌬ SN:*\n${resss.sn}\n\n_Terimakasih kak sudah order.️_`}, {quoted: msg})
clearInterval(intervals);
return;
} else if (resss.status === "GAGAL") {
console.log(resss)
	if (data_topup.pay === "yes") {
                addSaldo(sender, data_topup.data.price, db_saldo);
                reply(`*PESANAN GAGAL❌*\nSaldo Anda otomatis bertambah dan langsung bisa digunakan untuk topup kembali.\nSilakan ketik _#saldo_ untuk melihat saldo Anda.`);
            } else {
                reply(`❌ Pesanan dibatalkan!\nSilahkan melakukan transaksi ulang dan lapor ke owner kalau ada kendala transaksi`);
            }
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
clearInterval(intervals);
return;
} 
})
}, 5000)
	} else if (isListMessage === "batal") {
		reply(`Pesanan dibatalkan!`)
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
	}}}}
	
	const dbFile = "./database/stock.json";
function readDatabase() {
  if (!fs.existsSync(dbFile)) {
    fs.writeFileSync(dbFile, JSON.stringify({ produk: [], terjual: [] }));
  }
  const data = fs.readFileSync(dbFile, "utf8");
  return JSON.parse(data);
}
function saveDatabase(data) {
  fs.writeFileSync(dbFile, JSON.stringify(data, null, 2));
}
function addProduk(id, nama, desk, harga) {
  let database = readDatabase();

  if (database.produk.find((p) => p.id === id)) {
    reply(`Produk dengan ID *${id}* sudah ada!`);
    return;
  }
  database.produk.push({ id, nama, desk, harga, akun: [], terjual: 0 });
  saveDatabase(database);
  reply(`Produk *${nama}* ID: ${id}* berhasil ditambahkan dengan harga Rp${harga}!`);
}
function delProduk(id) {
  let database = readDatabase();

  let index = database.produk.findIndex((p) => p.id === id);
  if (index === -1) {
    reply(`Produk dengan ID *${id}* tidak ditemukan!`);
    return;
  }

  let produkHapus = database.produk.splice(index, 1);
  saveDatabase(database);
  reply(`Produk ${produkHapus[0].nama} (ID: ${id}) berhasil dihapus.`);
}
function addAkunKeProduk(id, akunList) {
  let database = readDatabase();

  let produk = database.produk.find((p) => p.id === id);
  if (!produk) {
    reply(`Produk dengan ID *${id}* tidak ditemukan!`);
    return;
  }

  if (!Array.isArray(akunList) || akunList.length === 0) {
    reply(`Data akun tidak valid. Pastikan format array benar\n\nGunakan dengan cara .addstock kodeProduk,username,password,email,deskripsi`);
    return;
  }

  akunList.forEach((akun) => {
    if (akun.username && akun.password && akun.email && akun.deskripsi) {
      produk.akun.push(akun);
    } else {
      reply(`Akun dengan username *${akun.username}* memiliki data tidak lengkap!`);
    }
  });

  saveDatabase(database);
  reply(`${akunList.length} akun berhasil ditambahkan ke produk *${produk.nama}*. Total akun: ${produk.akun.length}`);
}
function rekapTransaksi() {
    let database = readDatabase();

    let totalTerjual = 0;
    let totalPendapatan = 0;

    let textny = `*〔 REKAP SEMUA TRANSAKSI 〕*\n\n`;

    database.produk.forEach(produk => {
        let terjual = produk.terjual || 0;
        let pendapatan = terjual * produk.harga;

        totalTerjual += terjual;
        totalPendapatan += pendapatan;

        textny += `*「 ${produk.nama} 」*\n`;
        textny += `📈 Terjual: ${terjual}\n`;
        textny += `💰 Pendapatan: Rp${pendapatan.toLocaleString()}\n———————————\n\n`;
    });

    textny += `🔹 Total Produk Terjual: ${totalTerjual}\n`;
    textny += `💵 Total Pendapatan: Rp${totalPendapatan.toLocaleString()}`;
    reply(textny)
}
function editNamaProduk(id, namaBaru) {
    let database = readDatabase();

    let produk = database.produk.find(p => p.id === id);
    if (!produk) {
        reply(`Produk dengan ID *${id}* tidak ditemukan!`);
        return;
    }

    produk.nama = namaBaru;
    saveDatabase(database);
    reply(`Nama produk *${id}* berhasil diubah menjadi *${produk.nama}*`);
}
function editDeskripsiProduk(id, deskripsiBaru) {
    let database = readDatabase();

    let produk = database.produk.find(p => p.id === id);
    if (!produk) {
        reply(`Produk dengan ID *${id}* tidak ditemukan!`);
        return;
    }

    produk.deskripsi = deskripsiBaru;
    saveDatabase(database);
    reply(`Deskripsi produk *${id}* berhasil diperbarui: *${produk.deskripsi}*`);
}
function editHargaProduk(id, hargaBaru) {
    let database = readDatabase();

    let produk = database.produk.find(p => p.id === id);
    if (!produk) {
        reply(`Produk dengan ID *${id}* tidak ditemukan!`);
        return;
    }
    produk.harga = hargaBaru;
    saveDatabase(database);
    reply(`Harga produk *${id}* berhasil diperbarui: *Rp${produk.harga}*`);
}
function formatProdukList() {
  let database = readDatabase();
  if (database.produk.length === 0) {
    return "│❌ *Tidak ada produk tersedia saat ini.*";
  }

  let produkList = "";
  database.produk.forEach((produk) => {
    produkList += `├───〔  *${produk.nama}*  〕─\n│\n`;
    produkList += `│ *Harga:* Rp${produk.harga}\n`;
    produkList += `│ *Kode:* ${produk.id}\n`;
    produkList += `│ *Stok:* ${produk.akun.length} akun\n`;
    produkList += `│ *Terjual:* ${produk.terjual}\n`;
    produkList += `│ *Desk:* ${produk.desk || "Tidak ada deskripsi"}\n`;
    produkList += `│ *Ketik:* #buy ${produk.id},jumlah\n`;
    produkList += `├──────────────┾•ิ.•┽\n`;
  });

  return produkList;
}
function tampilkanProduk() {
  let response = `
╭──⌬「 𝘿𝘼𝙏𝘼 𝘽𝙊𝙏 」⌬
│• ᴄʀᴇᴀᴛᴏʀ : @${global.kontakOwner}
│• ʙᴏᴛ ɴᴀᴍᴇ : ${global.botName}
│• ᴏᴡɴᴇʀ ɴᴀᴍᴇ : ${global.ownerName} 
╰──────⌬

╭───────────────⌬
${formatProdukList()}│   *Cara membeli:*  
│  Ketik *#buy kodeproduk,jumlah*
│  Contoh: *#buy canva,1*
│
╰━━━━━━━━━━━━━━━━┅•ิ.•ஐ
  `;

 reply(response); 
}

// Console
if (isGroup && isCmd) {
console.log(colors.green.bold("[Group]") + " " + colors.brightCyan(time,) + " " + colors.black.bgYellow(command) + " " + colors.green("from") + " " + colors.blue(groupName));
}

if (!isGroup && isCmd) {
console.log(colors.green.bold("[Private]") + " " + colors.brightCyan(time,) + " " + colors.black.bgYellow(command) + " " + colors.green("from") + " " + colors.blue(pushname));
}

// Casenya
switch(command) {
	case 'help': case 'menu':{
		let simbol = `${pickRandom(["⭔","⌬","〆","»"])}`
var ramex = `./SCRIPT BY RAMAA GNNZ`
		if (isGroup) {
			let text = `╭━━━━━━━━━━━━━━━┅•ิ.•ஐ
│ *${ucapanWaktu} 🌻*                             
└┬────────────┾•ิ.•┽
┌┤     【 *BOT INFO🤖* 】
││
││○ *Store Name* : ${global.namaStore} 
││○ *Owner Number* : @${ownerNumber.split('@')[0]}
││○ *Owner Name* : ${global.ownerName} 
│└────────────┾•ิ.•┽
│
│      【 *ALL MENU??* 】
│${simbol} #allmenu
│${simbol} #pricelist (Topup)
│${simbol} #ordermenu (Auto order Account)
│
│Untuk Menampilkan Button
│Hanya dapat dilakukan Di
│Private Chat
╰━━━━━━━━━━━━━━━━┅•ิ.•ஐ `
ramz.sendMessage(from, {text: text, mentions: [sender]}, {quoted: msg})
} else {
var rows = [
{
title: "𝗣𝗥𝗜𝗖𝗘 𝗟𝗜𝗦𝗧 𝗧𝗢𝗣𝗨𝗣 ",
rowId: "#pricelist",
description: "Menampilkan layanan Yang tersedia"
},
{
title: "𝗗𝗘𝗣𝗢𝗦𝗜𝗧",
rowId: "#deposit",
description: "Untuk menambah saldo anda"
},
{
title: "𝗔𝗨𝗧𝗢 𝗢𝗥𝗗𝗘𝗥 𝗣𝗥𝗢𝗗𝗨𝗞",
rowId: "#ordermenu",
description: "Menampilkan Fitur Auto Order Produk akun"
},
{
title: "𝗠𝗘𝗡𝗨 𝗕𝗢𝗧",
rowId: "#menu2",
description: "Menampilkan Fitur bot WhatsApp"
},
{
title: "𝗢𝘄𝗻𝗲𝗿",
rowId: "#hubown",
description: "Pemilik Bot ini"
},
{
title: "𝗧𝗘𝗡𝗧𝗔𝗡𝗚 𝗕𝗢𝗧",
rowId: "#infobot",
description: "Cara Menggunakan bot & info bot"
}
]
var dep_but = {
text: `*${ucapanWaktu} 🌻 ${pushname}*
Saya adalah bot WhatsApp Yang 
menyediakan berbagai fitur menarik, 
Fitur utama dari saya adalah _Penyedia layanan Topup otomatis_

> Owner Number: @${ownerNumber.split('@')[0]}
> Shop Name: ${global.namaStore}`,
buttonText: "Pilih disini",
sections: [ { title: "Pilih sesuai kebutuhan Mu", rows } ],
mentions: [sender]
}
ramz.sendMessage(from, dep_but, {quoted: msg})
}
}
break
	case 'menu2': case 'allmenu': {
		const mark_slebew = '0@s.whatsapp.net'
const more = String.fromCharCode(8206)
const strip_ny = more.repeat(4001)
var footer_nya =`Creator by - ${global.ownerName}`
let simbol = `${pickRandom(["⭔","⌬","〆","»"])}`
var ramex = `./SCRIPT BY RAMAA GNNZ`
	let menu = `╭━━━━━━━━━━━━━━━┅•ิ.•ஐ
│ *${ucapanWaktu} 🌻 @${pushname}*                             
└┬────────────┾•ิ.•┽
┌┤     【 *BOT INFO🤖* 】
││
││○ *Store Name* : ${global.namaStore} 
││○ *Owner Number* : @${ownerNumber.split('@')[0]}
││○ *Owner Name* : ${global.ownerName} 
│└────────────┾•ิ.•┽
│
│
│      【 *FITUR TOPUP* 】
│
│${simbol} #pricelist     
│${simbol} #topup (Auto order)
│${simbol} #saldo (Saldo Anda)
│${simbol} #deposit
│${simbol} #depo 
│${simbol} #bukti (bukti deposit)
│${simbol} #cekff
│${simbol} #cekml
│
├──────────────┾•ิ.•┽
│
│      【 *AUTO ORDER MENU* 】
│
│${simbol} .caraorder
│${simbol} .stock
│${simbol} .stok
│${simbol} .buy (kodeProduk,jumlah)
│
│
│${simbol} .addproduk 
│${simbol} .addstock
│${simbol} .delproduk
│${simbol} .getstock
│${simbol} .rekap
│${simbol} .setnama / setnamaproduk
│${simbol} .setdesk / setdeskproduk
│${simbol} .setharga / setdeskproduk
│
├──────────────┾•ิ.•┽
│
│          𝙈𝙖𝙞𝙣 𝙈𝙚𝙣𝙪
│
│${simbol} #infobot
│${simbol} #deposit
│${simbol} #bukti
│${simbol} #donasi
│${simbol} #ping
│${simbol} #pembayaran 
│${simbol} #bayar
│${simbol} #s
│${simbol} #sticker 
├──────────────┾•ิ.•┽
│          𝙂𝙧𝙤𝙪𝙥 𝙈𝙚𝙣𝙪 』
│
│${simbol} #hidetag
│${simbol} #welcome (on/off)
│${simbol} #group open
│${simbol} #group close 
│${simbol} #antilink (kick)
│${simbol} #antilink2 (no kick)
│${simbol} #kick 
│${simbol} #proses
│${simbol} #done
│${simbol} #linkgc
│${simbol} #tagall
│${simbol} #fitnah
│${simbol} #revoke
│${simbol} #delete
│
│${simbol} #addlist (Support image)
│${simbol} #dellist
│${simbol} #list 
│${simbol} #shop
│${simbol} #hapuslist
├──────────────┾•ิ.•┽│       
│
│            𝙊𝙬𝙣𝙚𝙧 𝙈𝙚𝙣𝙪 
│
│${simbol} #addsaldo
│${simbol} #minsaldo
│${simbol} #addtesti
│${simbol} #deltesti
│${simbol} #join
│${simbol} #sendbyr 62xxx
│${simbol} #block 62xxx 
│${simbol} #unblock 62xxx
│${simbol} #gantiqris
│${simbol} #gantilogo
│${simbol} #backup
│
│
│${simbol} #ceksaldo (Saldo di apk)
│${simbol} #addsaldo (+ saldo user)
│${simbol} #minsaldo (- saldo user)
│${simbol} #cekip (ip provider)
│${simbol} #ceksaldo (saldo order kouta)
│${simbol} #setprofit (Set Keuntungan)
├──────────────┾•ิ.•┽│  
│     
│              Kalkulator 
│
│${simbol} #tambah
│${simbol} #kali
│${simbol} #bagi
│${simbol} #kurang 
╰━━━━━━━━━━━━━━━━┅•ิ.•ஐ `
ramz.sendMessage(from, {image: fs.readFileSync(`./gambar/thumbnail.jpg`),
 caption: menu,
mentions: [ownerNumber]},
 {quoted: msg})
}
break
case 'order': case 'ordermenu': {
		const mark_slebew = '0@s.whatsapp.net'
const more = String.fromCharCode(8206)
const strip_ny = more.repeat(4001)
var footer_nya =`Creator by - ${global.ownerName}`
let simbol = `${pickRandom(["⭔","⌬","〆","»"])}`
var ramex = `./SCRIPT BY RAMAA GNNZ`
	let menu = `╭━━━━━━━━━━━━━━━┅•ิ.•ஐ
│ *${ucapanWaktu} 🌻 @${pushname}*                             
└┬────────────┾•ิ.•┽
┌┤     【 *BOT INFO🤖* 】
││
││○ *Store Name* : ${global.namaStore} 
││○ *Owner Number* : @${ownerNumber.split('@')[0]}
││○ *Owner Name* : ${global.ownerName} 
│└────────────┾•ิ.•┽
│
│      【 *AUTO ORDER MENU* 】
│
│${simbol} .stock
│${simbol} .stok
│${simbol} .buy (kodeProduk,jumlah)
│
│
│${simbol} .addproduk 
│${simbol} .addstock
│${simbol} .delproduk
│${simbol} .rekap
│${simbol} .setnama / setnamaproduk
│${simbol} .setdesk / setdeskproduk
│${simbol} .setharga / setdeskproduk
│
╰━━━━━━━━━━━━━━━━┅•ิ.•ஐ `
ramz.sendMessage(from, {image: fs.readFileSync(`./gambar/thumbnail.jpg`),
 caption: menu,
mentions: [ownerNumber]},
 {quoted: msg})
}
break
case 'sticker': case 's': case 'stiker':{
if (isImage || isQuotedImage) {
let media = await downloadAndSaveMediaMessage('image', `./gambar/${tanggal}.jpg`)
reply(mess.wait)
ramz.sendImageAsSticker(from, media, msg, { packname: `${global.namaStore}`, author: `Store Bot`})
} else if (isVideo || isQuotedVideo) {
let media = await downloadAndSaveMediaMessage('video', `./gambar/${tanggal}.mp4`)
reply(mess.wait)
ramz.sendVideoAsSticker(from, media, msg, { packname: `${global.namaStore}`, author: `Store Bot`})
} else {
reply(`Kirim/reply gambar/vidio dengan caption *${prefix+command}*`)
}
}
break
case 'cekff':{
if (!q) return reply(`Kirim perintah ${prefix+command} id\nContoh: ${prefix+command} 2023873618`)
let anu = await fetchJson('https://api.gamestoreindonesia.com/v1/order/prepare/FREEFIRE?userId=' + q + '&zoneId=null')
if (!anu.statusCode == "404") return reply("Id tidak ditemukan")
    let dataa = anu.data
reply(`*BERHASIL DITEMUKAN*
ID: ${q}
Nickname: ${dataa}`)
}
break
case 'cekml':{
if (!q) return reply(`Kirim perintah ${prefix+command} id|zone\nContoh: ${prefix+command} 106281329|2228`)
var id = q.split('|')[0]
var zon = q.split('|')[1]
if (!id) return reply('ID wajib di isi')
if (!zon) return reply('ZoneID wajib di isi')
let anu = await fetchJson('https://api.gamestoreindonesia.com/v1/order/prepare/MOBILE_LEGENDS?userId=' + id + '&zoneId=' + zon)
if (!anu.statusCode == "404") return reply("Id/zone tidak ditemukan")
    let dataa = anu.data
reply(`*BERHSAIL DITEMUKAN*
ID: ${id}
Zone: ${zon}
Nickname: ${dataa}`)
}
break
case 'owner':{
var owner_Nya = `${global.ownerNumber}`
sendContact(from, owner_Nya, `${global.ownerName}`, msg)
reply('*Itu kak nomor owner ku, Chat aja gk usah malu😆*')
}
break
case 'hubown':
reply(`Hallo kak✨\nJikalau ada bug maupun masalah bisa lapor ke owner ya kak, kaka juga bisa berkenalan dengan owner saya\n(wa.me/${global.kontakOwner})`)
break
case 'yt':
case 'youtube':
	ramz.sendMessage(from, 
{text: `Jangan Lupa Subscriber yah kak😉🙏
*Link* : ${global.linkyt}`},
{quoted: msg})
break
case 'ig':
case 'instagram':
	ramz.sendMessage(from, {text: `Admin Kurang ngurus ig uyy Jadi subscribe aja YouTube admin\n\nLink \n${global.linkig}`},
{quoted: msg})
break
case 'gc':
case 'groupadmin':
	ramz.sendMessage(from, 
{text: `*Group  ${global.ownerName}*\n
Group1 : ${global.linkgc1}
Group2 : ${global.linkgc2}`},
{quoted: msg})
break
case 'donasi': case 'donate':{
let tekssss = `───「  *DONASI*  」────

*Payment donasi💰* 

- *Dana :* ${global.dana}
- *Gopay :*  ${global.gopay}
- *Ovo :* ${global.ovo}
- *Saweria :* ${global.sawer}

berapapun donasi dari kalian itu sangat berarti bagi kami 
`
ramz.sendMessage(from, { image: fs.readFileSync(`./gambar/qris.jpg`),
 caption: tekssss, 
footer: `${global.ownerName} © 2022`},
{quoted: msg})
}
break
case 'sendbyr':{
	if (!isOwner) return reply(mess.OnlyOwner)
	if (!q) return reply('*Contoh:*\n.add 628xxx')
	var number = q.replace(/[^0-9]/gi, '')+'@s.whatsapp.net'
let tekssss = `───「  *PAYMENT*  」────

- *Dana :* ${global.dana}
- *Gopay :*  ${global.gopay}
- *Ovo :* ${global.ovo}

_Pembayaran ini Telah di kirim oleh Admin_
_Melalui bot ini🙏_


OK, thanks udah order di *${global.namaStore}*
`
ramz.sendMessage(number, { image: fs.readFileSync(`./gambar/qris.jpg`),
 caption: tekssss, 
footer: `${global.ownerName} © 2022`},
{quoted: msg})
reply (`Suksess Owner ku tercinta 😘🙏`)
}
break
case 'join': {
    if (!isOwner) return reply(mess.OnlyOwner)
    if (!q) return reply(`Kirim perintah ${prefix + command} _linkgrup_\n\nContoh:\n${prefix + command} https://chat.whatsapp.com/abcdefgHIJKL123`)
    let code = q.split('https://chat.whatsapp.com/')[1]
    if (!code) return reply('❌ Link grup tidak valid! Pastikan formatnya benar.')
    code = code.split('?')[0] // hapus parameter tambahan seperti ?mode=
    try {
        await ramz.groupAcceptInvite(code)
        reply('✅ Berhasil join ke grup!')
    } catch (err) {
        console.log(err)
        reply('❌ Gagal join grup. Mungkin bot sudah pernah dikeluarkan atau link sudah kadaluarsa.')
    }
}
break
case 'payment':
case 'pembayaran':
case 'bayar':{
let tekssss = `───「  *PAYMENT*  」────

- *Dana :* ${global.dana}
- *Gopay :*  ${global.gopay}
- *Ovo :* ${global.ovo}

OK, thanks udah order di *${global.botName}*
`
ramz.sendMessage(from, { image: fs.readFileSync(`./gambar/qris.jpg`),
 caption: tekssss, 
footer: `${global.ownerName} © 2022`},
{quoted: msg})
}
break
case 'infobot': case 'informasi': case 'tentangbot':
reply(`*Selamat datang di Bot WhatsApp kami!*
Kami menyediakan berbagai layanan unggulan yang memudahkan Anda dalam melakukan berbagai transaksi dengan cepat dan otomatis. Berikut adalah beberapa fitur utama yang dapat Anda nikmati:

• Top-up Otomatis (PPOB)
• Sistem Deposit Otomatis & Auto Order
• Transaksi mudah menggunakan button (Tombol)
• Transaksi cepat dan aman
• Layanan 24/7 siap membantu kapan saja
Tampilan yang mudah digunakan
• Proses transaksi yang transparan dan efisien
Bergabunglah dengan kami dan nikmati layanan terbaik untuk mempermudah berbagai transaksi Anda!

Cara menggunakan: https://youtu.be/1silEQLjbiM?si=f9cQVdZI93sgbdtm`)
break
case 'gantiqris':{
	if (!isOwner) return reply(mess.OnlyOwner)
if (isImage || isQuotedImage) {
	let media = await downloadAndSaveMediaMessage('image', `./gambar/${sender}`)
	fs.unlinkSync(`./gambar/qris.jpg`)
	fs.renameSync(media, `./gambar/qris.jpg`)
reply(`Sukses mengganti Image Qris`)
} else {
	reply(`kirim gambar/reply gambar dengan caption .gantiqris`)
}
}
break
case 'gantilogo':{
	if (!isOwner) return reply(mess.OnlyOwner)
if (isImage || isQuotedImage) {
	let media = await downloadAndSaveMediaMessage('image', `./gambar/${sender}`)
	fs.unlinkSync(`./gambar/logo.jpg`)
	fs.renameSync(media, `./gambar/logo.jpg`)
reply(`Sukses mengganti Logo kamu`)
} else {
	reply(`kirim gambar/reply gambar dengan caption .gantilogo`)
}
}
break
case 'gantithumbnail':{
	if (!isOwner) return reply(mess.OnlyOwner)
if (isImage || isQuotedImage) {
	let media = await downloadAndSaveMediaMessage('image', `./gambar/${sender}`)
	fs.unlinkSync(`./gambar/thumbnail.jpg `)
	fs.renameSync(media, `./gambar/thumbnail.jpg`)
reply(`Sukses mengganti Logo kamu`)
} else {
	reply(`kirim gambar/reply gambar dengan caption .gantithumbnail`)
}
}
break
case 'p': case 'proses':{
if (!msg.key.fromMe && ! isOwner && !isGroup) return reply('Hanya Dapat Digunakan oleh Owner/admingrup')
if (!msg.key.fromMe && ! isOwner && !isGroupAdmins) return reply('Hanya Dapat Digunakan oleh Owner/admingrup')
if (!quotedMsg) return reply('Reply pesanannya!')
let proses = `「 *TRANSAKSI PENDING* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM     : ${jam}\n✨ STATUS  : Pending\`\`\`\n\n📝 Catatan : ${quotedMsg.chats}\n\nPesanan @${quotedMsg.sender.split("@")[0]} sedang di proses!`
mentions(proses, [quotedMsg.sender], true)
}
break
case 'd': case 'done':{
if (!msg.key.fromMe && ! isOwner && !isGroup) return reply('Hanya Dapat Digunakan oleh Owner/admingrup')
if (!msg.key.fromMe && ! isOwner && !isGroupAdmins) return reply('Hanya Dapat Digunakan oleh Owner/admingrup')
if (!quotedMsg) return reply('Reply pesanannya!')
let sukses = `「 *TRANSAKSI BERHASIL* 」\n\n\`\`\`📆 TANGGAL : ${tanggal}\n⌚ JAM     : ${jam}\n✨ STATUS  : Berhasil\`\`\`\n\nTerimakasih @${quotedMsg.sender.split("@")[0]} Next Order ya??`
mentions(sukses, [quotedMsg.sender], true)

}
break
case 'tambah':
if (!q) return reply(`Gunakan dengan cara ${command} *angka* *angka*\n\n_Contoh_\n\n${command} 1 2`)
var num_one = q.split(' ')[0]
var num_two = q.split(' ')[1]
if (!num_one) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
if (!num_two) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
var nilai_one = Number(num_one)
var nilai_two = Number(num_two)
reply(`${nilai_one + nilai_two}`)
break
case 'kurang':
if (!q) return reply(`Gunakan dengan cara ${command} *angka* *angka*\n\n_Contoh_\n\n${command} 1 2`)
var num_one = q.split(' ')[0]
var num_two = q.split(' ')[1]
if (!num_one) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
if (!num_two) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
var nilai_one = Number(num_one)
var nilai_two = Number(num_two)
reply(`${nilai_one - nilai_two}`)
break
case 'kali':
if (!q) return reply(`Gunakan dengan cara ${command} *angka* *angka*\n\n_Contoh_\n\n${command} 1 2`)
var num_one = q.split(' ')[0]
var num_two = q.split(' ')[1]
if (!num_one) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
if (!num_two) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
var nilai_one = Number(num_one)
var nilai_two = Number(num_two)
reply(`${nilai_one * nilai_two}`)
break
case 'bagi':
if (!q) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${command} 1 2`)
var num_one = q.split(' ')[0]
var num_two = q.split(' ')[1]
if (!num_one) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
if (!num_two) return reply(`Gunakan dengan cara ${prefix+command} *angka* *angka*\n\n_Contoh_\n\n${prefix+command} 1 2`)
var nilai_one = Number(num_one)
var nilai_two = Number(num_two)
reply(`${nilai_one / nilai_two}`)
break
case 'hidetag':
if (!isGroup) return reply('Fitur ini hanya dapat digunakan didalam group')
if (!isGroupAdmins) return reply('Kamu bukan admin, Fitur ini hanya dapat digunakan oleh admin group')
if (!isBotGroupAdmins) return reply('Bot harus admin')
let mem = [];
groupMembers.map( i => mem.push(i.id) )
ramz.sendMessage(from, { text: q ? q : '', mentions: mem })
break
case 'antilink':{
if (!isGroup) return reply('Fitur ini hanya dapat digunakan didalam group')
if (!isGroupAdmins) return reply('Kamu bukan admin, Fitur ini hanya dapat digunakan oleh admin group')
if (!isBotGroupAdmins) return reply('Bot harus admin')
if (!args[0]) return reply(`Kirim perintah #${command} _options_\nOptions : on & off\nContoh : #${command} on`)
if (args[0] == 'ON' || args[0] == 'on' || args[0] == 'On') {
if (isAntiLink) return reply('Antilink sudah aktif')
antilink.push(from)
fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
reply('Successfully Activate Antilink In This Group')
} else if (args[0] == 'OFF' || args[0] == 'OF' || args[0] == 'Of' || args[0] == 'Off' || args[0] == 'of' || args[0] == 'off') {
if (!isAntiLink) return reply('Antilink belum aktif')
let anu = antilink.indexOf(from)
antilink.splice(anu, 1)
fs.writeFileSync('./database/antilink.json', JSON.stringify(antilink, null, 2))
reply('Successfully Disabling Antilink In This Group')
} else { reply('Kata kunci tidak ditemukan!') }
}
break
case 'tagall':
if (!isGroup) return reply('Khusus Didalam Group')
if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
if (!q) return reply(`Teks?\nContoh #tagall hallo`)
let teks_tagall = `══✪〘 *👥 Tag All* 〙✪══\n\n${q ? q : ''}\n\n`
for (let mem of participants) {
teks_tagall += `➲ @${mem.id.split('@')[0]}\n`
}
ramz.sendMessage(from, { text: teks_tagall, mentions: participants.map(a => a.id) }, { quoted: msg })
break
case 'fitnah':
if (!isGroup) return reply('Khusus Didalam Group')
if (!q) return reply(`Kirim perintah #*${command}* @tag|pesantarget|pesanbot`)
var org = q.split("|")[0]
var target = q.split("|")[1]
var bot = q.split("|")[2]
if (!org.startsWith('@')) return reply('Tag orangnya')
if (!target) return reply(`Masukkan pesan target!`)
if (!bot) return reply(`Masukkan pesan bot!`)
var mens = parseMention(target)
var msg1 = { key: { fromMe: false, participant: `${parseMention(org)}`, remoteJid: from ? from : '' }, message: { extemdedTextMessage: { text: `${target}`, contextInfo: { mentionedJid: mens }}}}
var msg2 = { key: { fromMe: false, participant: `${parseMention(org)}`, remoteJid: from ? from : '' }, message: { conversation: `${target}` }}
ramz.sendMessage(from, { text: bot, mentions: mentioned }, { quoted: mens.length > 2 ? msg1 : msg2 })
break
case 'del':
case 'delete':
if (!isGroup) return reply('Khusus Didalam Group')
if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
if (!quotedMsg) return reply(`Balas chat dari bot yang ingin dihapus`)
if (!quotedMsg.fromMe) return reply(`Hanya bisa menghapus chat dari bot`)
ramz.sendMessage(from, { delete: { fromMe: true, id: quotedMsg.id, remoteJid: from }})
break
case 'linkgrup': case 'linkgc':
if (!isGroup) return reply('Khusus Didalam Group')
if (!isBotGroupAdmins) return reply(mess.BotAdmin)
var url = await ramz.groupInviteCode(from).catch(() => reply(mess.error.api))
url = 'https://chat.whatsapp.com/'+url
reply(url)
break
case 'revoke':
if (!isGroup) return reply('Khusus Didalam Group')
if (!isGroupAdmins) return reply(mess.GrupAdmin)
if (!isBotGroupAdmins) return reply(mess.BotAdmin)
await ramz.groupRevokeInvite(from)
.then( res => {
reply(`Sukses menyetel tautan undangan grup ini`)
}).catch(() => reply(mess.error.api))
break
case 'antilink2':{
if (!isGroup) return reply('Fitur ini hanya dapat digunakan didalam group')
if (!isGroupAdmins) return reply('Kamu bukan admin, Fitur ini hanya dapat digunakan oleh admin group')
if (!isBotGroupAdmins) return reply('Bot harus admin')
if (!args[0]) return reply(`Kirim perintah #${command} _options_\nOptions : on & off\nContoh : #${command} on`)
if (args[0] == 'ON' || args[0] == 'on' || args[0] == 'On') {
if (isAntiLink2) return reply('Antilink 2 sudah aktif')
antilink2.push(from)
fs.writeFileSync('./database/antilink2.json', JSON.stringify(antilink2, null, 2))
reply('Successfully Activate Antilink 2 In This Group')
} else if (args[0] == 'OFF' || args[0] == 'OF' || args[0] == 'Of' || args[0] == 'Off' || args[0] == 'of' || args[0] == 'off') {
if (!isAntiLink2) return reply('Antilink 2 belum aktif')
let anu = antilink2.indexOf(from)
antilink2.splice(anu, 1)
fs.writeFileSync('./database/antilink2.json', JSON.stringify(antilink2, null, 2))
reply('Successfully Disabling Antilink 2 In This Group')
} else { reply('Kata kunci tidak ditemukan!') }
}
break
case 'group':
case 'grup':
if (!isGroup) return reply('Fitur ini hanya dapat digunakan didalam group')
if (!isGroupAdmins) return reply('Kamu bukan admin, Fitur ini hanya dapat digunakan oleh admin group')
if (!isBotGroupAdmins) return reply('Bot harus admin')
if (!q) return reply(`Kirim perintah #${command} _options_\nOptions : close & open\nContoh : #${command} close`)
if (args[0] == "close") {
ramz.groupSettingUpdate(from, 'announcement')
reply(`Sukses mengizinkan hanya admin yang dapat mengirim pesan ke grup ini`)
} else if (args[0] == "open") {
ramz.groupSettingUpdate(from, 'not_announcement')
reply(`Sukses mengizinkan semua peserta dapat mengirim pesan ke grup ini`)
} else {
reply(`Kirim perintah #${command} _options_\nOptions : close & open\nContoh : #${command} close`)
}
break
case 'kick':
if (!isGroup) return reply('Fitur ini hanya dapat digunakan didalam group')
if (!isGroupAdmins) return reply('Kamu bukan admin, Fitur ini hanya dapat digunakan oleh admin group')
if (!isBotGroupAdmins) return reply('Bot harus admin')
var number;
if (mentionUser.length !== 0) {
number = mentionUser[0]
ramz.groupParticipantsUpdate(from, [number], "remove")
.then( res => 
reply(`*Sukses mengeluarkan member..!*`))
.catch((err) => reply(mess.error.api))
} else if (isQuotedMsg) {
number = quotedMsg.sender
ramz.groupParticipantsUpdate(from, [number], "remove")
.then( res => 
reply(`*Sukses mengeluarkan member..!*`))
.catch((err) => reply(mess.error.api))
} else {
reply(`Tag atau balas pesan orang yang ingin dikeluarkan dari grup`)
}
break
case 'welcome':{
if (!isGroup) return reply('Khusus Group!') 
if (!msg.key.fromMe && !isOwner && !isGroupAdmins) return reply("Mau ngapain?, Fitur ini khusus admin")
if (!args[0]) return reply('*Kirim Format*\n\n.welcome on\n.welcome off')
if (args[0] == 'ON' || args[0] == 'on' || args[0] == 'On') {
if (isWelcome) return reply('Sudah aktif✓')
welcome.push(from)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome))
reply('Suksess mengaktifkan welcome di group:\n'+groupName)
} else if (args[0] == 'OFF' || args[0] == 'OF' || args[0] == 'Of' || args[0] == 'Off' || args[0] == 'of' || args[0] == 'off') {
var posi = welcome.indexOf(from)
welcome.splice(posi, 1)
fs.writeFileSync('./database/welcome.json', JSON.stringify(welcome))
reply('Success menonaktifkan welcome di group:\n'+groupName)
} else { reply('Kata kunci tidak ditemukan!') }
}
break
case 'block':{
if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
if (!q) return reply(`Ex : ${prefix+command} Nomor Yang Ingin Di Block\n\nContoh :\n${prefix+command} 628xxxx`)
let nomorNya = q
await ramz.updateBlockStatus(`${nomorNya}@s.whatsapp.net`, "block") // Block user
reply('Sukses Block Nomor')
}
break
case 'unblock':{
if (!isOwner && !fromMe) return reply(mess.OnlyOwner)
if (!q) return reply(`Ex : ${prefix+command} Nomor Yang Ingin Di Unblock\n\nContoh :\n${prefix+command} 628xxxx`)
let nomorNya = q
await ramz.updateBlockStatus(`${nomorNya}@s.whatsapp.net`, "unblock")
reply('Sukses Unblock Nomor')
}
break
case 'shop':
case 'list':
  if (!isGroup) {
    return reply('Khusus Didalam Group');
  }
  if (db_respon_list.length === 0) {
    return reply(`Belum ada list message di database`);
  }
  if (!isAlreadyResponListGroup(from, db_respon_list)) {
    return reply(`Belum ada list message yang terdaftar di group ini`);
  }
  var arr_rows = [];
  for (let x of db_respon_list) {
    if (x.id === from) {
      arr_rows.push({
        title: x.key,
        rowId: x.key
      });
    }
  }
  let tekny = `Hai @${sender.split("@")[0]}\nBerikut list item yang tersedia di group ini!\n\nSilahkan ketik nama produk yang diinginkan!\n\n`;
  for (let i of arr_rows) {
    tekny += `🛍️ Produk : ${i.title}\n`;
  }
  var listMsg = {
    text: tekny,
    mentions: [sender]
  };
  ramz.sendMessage(from, listMsg);
  break;
case 'addlist':
if (!isGroup) return reply('Khusus Didalam Group')
if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
var args1 = q.split("@")[0]
var args2 = q.split("@")[1]
if (!q.includes("@")) return reply(`Gunakan dengan cara ${command} *key@response*\n\n_Contoh_\n\n#${command} tes@apa\n\nAtau kalian bisa Reply/Kasih Image dengan caption: #${command} tes@apa`)
if (isImage || isQuotedImage) {
if (isAlreadyResponList(from, args1, db_respon_list)) return reply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
let media = await downloadAndSaveMediaMessage('image', `./gambar/${sender.split('@')[0]}.jpg`)
let url = await TelegraPh(media)
addResponList(from, args1, args2, true, url, db_respon_list)
reply(`Berhasil menambah List menu : *${args1}*`)
if (fs.existsSync(media)) return fs.unlinkSync(media)
} else {
	if (isAlreadyResponList(from, args1, db_respon_list)) return reply(`List respon dengan key : *${args1}* sudah ada di group ini.`)
	addResponList(from, args1, args2, false, '-', db_respon_list)
reply(`Berhasil menambah List menu : *${args1}*`)
}
break
case 'dellist':{
if (!isGroup) return reply('Khusus Didalam Group')
if (!isGroupAdmins && !isOwner) return reply(mess.GrupAdmin)
if (db_respon_list.length === 0) return reply(`Belum ada list message di database`)
var arr_rows = [];
for (let x of db_respon_list) {
if (x.id === from) {
arr_rows.push({
title: x.key,
rowId: `#hapuslist ${x.key}`
})
}
}
let tekny = `Hai @${sender.split("@")[0]}\nSilahkan Hapus list dengan Mengetik #hapuslist Nama list\n\nContoh: #hapuslist Tes\n\n`;
  for (let i of arr_rows) {
    tekny += `List : ${i.title}\n`;
  }
var listMsg = {
    text: tekny,
  };
ramz.sendMessage(from, listMsg)
}
break
case 'hapuslist':
delResponList(from, q, db_respon_list)
reply(`Sukses delete list message dengan key *${q}*`)
break
case 'testi':{
if (isGroup) return reply('Khusus Di Private Chat')
if (db_respon_testi.length === 0) return reply(`Belum ada list testi di database`)
var teks = `Hi @${sender.split("@")[0]}\nBerikut list testi\n\n`
for (let x of db_respon_testi) {
teks += `*LIST TESTI:* ${x.key}\n`
}
teks += `_Ingin melihat listnya?_\n_Ketik List Testi yang ada di atss_`
var listMsg = {
text: teks,
mentions: [sender]
}
ramz.sendMessage(from, listMsg, { quoted: msg })
}
break
case 'addtesti':
if (isGroup) return reply('Khusus Di Private Chat')
if (!isOwner) return reply(mess.OnlyOwner)
var args1 = q.split("@")[0]
var args2 = q.split("@")[1]
if (isImage || isQuotedImage) {
if (!q.includes("@")) return reply(`Gunakan dengan cara ${prefix+command} *key@response*\n\n_Contoh_\n\n${prefix+command} testi1@testimoni sc bot`)
if (isAlreadyResponTesti(args1, db_respon_testi)) return reply(`List respon dengan key : *${args1}* sudah ada.`)
let media = await downloadAndSaveMediaMessage('image', `./gambar/${sender}`)
let tphurl = await TelegraPh(media)
addResponTesti(args1, args2, true, tphurl, db_respon_testi)
reply(`Berhasil menambah List testi *${args1}*`)
if (fs.existsSync(media)) return fs.unlinkSync(media)
} else {
	reply(`Kirim gambar dengan caption ${prefix+command} *key@response* atau reply gambar yang sudah ada dengan caption ${prefix+command} *key@response*`)
	}
break
case 'deltesti':
if (isGroup) return reply('Khusus Di Private Chat')
if (!isOwner) return reply(mess.OnlyOwner)
if (db_respon_testi.length === 0) return reply(`Belum ada list testi di database`)
if (!q) return reply(`Gunakan dengan cara ${prefix+command} *key*\n\n_Contoh_\n\n${prefix+command} testi1`)
if (!isAlreadyResponTesti(q, db_respon_testi)) return reply(`List testi dengan key *${q}* tidak ada di database!`)
delResponTesti(q, db_respon_testi)
reply(`Sukses delete list testi dengan key *${q}*`)
break
case 'deposit': case 'depo':{
	if (isGroup) return reply('Khusus Di Private Chat')
var rows = [
{
title: "QRIS",
rowId: "payqris",
description: "Sistem: Otomatis"
},
{
title: "DANA",
rowId: "paydana",
description: "Sistem: manual"
}
]
var dep_but = {
text: `ingin melakukan deposit saldo? silahkan pilih payment yang tersedia☺`,
buttonText: "Pilih disini",
sections: [ { title: "PAYMENT DEPOSIT", rows } ]
}
ramz.sendMessage(from, dep_but)
}
break
case 'bukti':
if (!fs.existsSync(depositPath + sender.split("@")[0] + ".json")) return reply(`Maaf *@${sender.split('@')[0]}* sepertinya kamu belum pernah melakukan deposit`)
if (isImage && isQuotedImage) return reply(`Kirim gambar dengan caption *#bukti* atau reply gambar yang sudah dikirim dengan caption *#bukti*`)
await ramz.downloadAndSaveMediaMessage(msg, "image", `./database/deposit/${sender.split('@')[0]}.jpg`)

let oke_bang = fs.readFileSync(`./database/deposit/${sender.split('@')[0]}.jpg`)
let data_depo = JSON.parse(fs.readFileSync(depositPath + sender.split("@")[0] + ".json"))

let caption_bukti =`「 *DEPOSIT USER* 」
⭔ID: ${data_depo.ID}
⭔Nomer: @${data_depo.number.split('@')[0]}
⭔Payment: ${data_depo.payment}
⭔Tanggal: ${data_depo.date.split(' ')[0]}
⭔Jumlah Deposit: Rp${toRupiah(data_depo.data.amount_deposit)}
⭔Pajak Admin : Rp0
⭔Total Pembayaran : Rp${toRupiah(data_depo.data.amount_deposit)}

Ada yang deposit nih kak, coba dicek saldonya, jika sudah masuk konfirmasi

Jika sudah masuk konfirmasi dengan cara klik *#accdepo*
Jika belum masuk batalkan dengan cara ketik *#rejectdepo*`

let bukti_bayar = {
image: oke_bang,
caption: caption_bukti,
mentions: [data_depo.number],
title: 'Bukti pembayaran',
footer: 'Press The Button Below',
headerType: 5 
}
ramz.sendMessage(`${global.ownerNumber}`, bukti_bayar)
reply(`Mohon tunggu ya kak, sampai di Konfirmasi oleh owner ☺`)
fs.unlinkSync(`./database/deposit/${sender.split('@')[0]}.jpg`)
break
case 'accdepo':{
if (!isOwner) return reply(mess.OnlyOwner)
if (!q) return reply(`Contoh: ${prefix+command} 628xxx`)
let orang = q.split(",")[0].replace(/[^0-9]/g, '')
let data_deposit = JSON.parse(fs.readFileSync(depositPath + orang + '.json'))
addSaldo(data_deposit.number, Number(data_deposit.data.amount_deposit), db_saldo)
var text_sukses = `「 *DEPOSIT SUKSES* 」
⭔ID : ${data_deposit.ID}
⭔Nomer: @${data_deposit.number.split('@')[0]}
⭔Nomer: ${data_deposit.number.split('@')[0]}
⭔Payment: ${data_deposit.payment}
⭔Tanggal: ${data_deposit.date.split(' ')[0]}
⭔Jumlah Deposit: Rp${toRupiah(data_deposit.data.amount_deposit)}`
reply(`${text_sukses}\n`)
ramz.sendMessage(data_deposit.number, { text: `${text_sukses}\n\n_Deposit kamu telah dikonfirmasi oleh admin, silahkan cek saldo dengan cara ketik #saldo_`})
fs.unlinkSync(depositPath + data_deposit.number.split('@')[0] + ".json")
}
break
case 'rejectdepo':{
if (!isOwner) return reply(mess.OnlyOwner)
if (!q) return reply(`Contoh: ${prefix+command} 628xxx`)
let orang = q.split(",")[0].replace(/[^0-9]/g, '')
let data_deposit = JSON.parse(fs.readFileSync(depositPath + orang + '.json'))
reply(`Sukses Reject  Deposit `)
ramz.sendMessage(data_deposit.number, { text: `Maaf Deposit Dengan ID : *${data_deposit.ID}* Ditolak, Jika ada kendala hubungin Owner Bot.\nwa.me/${global.ownerNumber}`})
fs.unlinkSync(depositPath + data_deposit.number.split('@')[0] + ".json")
}
break

case 'saldo':{
reply(`*━━ CHECK YOUR INFO ━━* 

 _• *Name:* ${pushname}_
 _• *Nomer:* ${sender.split('@')[0]}_
 _• *Saldo:* Rp${toRupiah(cekSaldo(sender, db_saldo))}_

*Note :*
_Saldo hanya bisa untuk topup_
_Tidak bisa ditarik atau transfer_!`)
}
break
case 'addsaldo':
if (!isOwner) return reply(mess.OnlyOwner)
if (!q) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
if (!q.split("|")[0]) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
if (!q.split("|")[1]) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
addSaldo(q.split("|")[0]+"@s.whatsapp.net", Number(q.split("|")[1]), db_saldo)
await sleep(50)
ramz.sendTextMentions(from, `「 *SALDO USER* 」
⭔ID: ${q.split("|")[0]}
⭔Nomer: @${q.split("|")[0]}
⭔Tanggal: ${tanggal}
⭔Saldo: Rp${toRupiah(cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo))}`, [q.split("|")[0]+"@s.whatsapp.net"])
ramz.sendTextMentions(q.split("|")[0]+"@s.whatsapp.net", `「 *SALDO USER* 」
⭔ID: ${q.split("|")[0]}
⭔Nomer: @${q.split("|")[0]}
⭔Tanggal: ${tanggal}
⭔Saldo: Rp${toRupiah(cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo))}`, [q.split("|")[0]+"@s.whatsapp.net"])
break
case 'minsaldo':
if (!isOwner) return reply(mess.OnlyOwner)
if (!q) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
if (!q.split("|")[0]) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
if (!q.split("|")[1]) return reply(`Ex : ${prefix+command} Nomor|Jumlah\n\nContoh :\n${prefix+command} 6285791220179|20000`)
if (cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo) == 0) return reply("Dia belum terdaftar di database saldo.")
if (cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo) < q.split("|")[1] && cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo) !== 0) return reply(`Dia saldonya ${cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo)}, jadi jangan melebihi ${cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo)} yah kak??`)
minSaldo(q.split("|")[0]+"@s.whatsapp.net", Number(q.split("|")[1]), db_saldo)
await sleep(50)
ramz.sendTextMentions(from, `「 *SALDO USER* 」
⭔ID: ${q.split("|")[0]}
⭔Nomer: @${q.split("|")[0]}
⭔Tanggal: ${tanggal}
⭔Saldo: Rp${toRupiah(cekSaldo(q.split("|")[0]+"@s.whatsapp.net", db_saldo))}`, [q.split("|")[0]+"@s.whatsapp.net"])
break
case 'backup': {
if (!isOwner) return reply(mess.OnlyOwner)
var anumu = await fs.readFileSync(`./database/saldo.json`)
ramz.sendMessage(from, { document: anumu, mimetype: 'document/application', fileName: 'saldo.json'})
await sleep(1000)
var anumuu = await fs.readFileSync(`./database/list.json`)
ramz.sendMessage(from, { document: anumuu, mimetype: 'document/application', fileName: 'list.json'})
await sleep(1000)
var anumuuu = await fs.readFileSync(`./database/list-produk.json`)
ramz.sendMessage(from, { document: anumuuu, mimetype: 'document/application', fileName: 'list-produk.json'})
await sleep(1000)
var anumuuu = await fs.readFileSync(`./database/stock.json`)
ramz.sendMessage(from, { document: anumuuu, mimetype: 'document/application', fileName: 'stock.json'})
await sleep(1000)
reply(`Taruh file file itu di folder database 

1. hapus beberapa file yang namanya sama seperti file yang dikirim oleh bot di folder database 

2. pindahkan file-file yang dikirim oleh bot ke folder database`)
}
break
case 'topup':{
	if (isGroup) return reply('Untuk penggunaan topup di group silahkan ketik *topup2*')
if (!q) return reply(`Ingin Topup? silahkan ketik #pricelist`)
if (!fs.existsSync(topupPath + sender.split("@")[0] + ".json")) {

axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
.then(async ress => {
	   if (!Array.isArray(ress)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let listproduk
for (let x of ress) {
if (x.kode == q.split(",")[0]) {
listproduk = x ? x : false
}
}
if (!listproduk) return reply(`_Code produk *${q.split(",")[0]}* Tidak sesuai_`)
let kntungan = (untung / 100) * listproduk.harga.replace(/[^0-9]/g, '')
if (cekSaldo(sender, db_saldo) < Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan))) {
 reply(`saldo anda kurang dari Rp${toRupiah(Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)))}\nBot akan mengirim pembayaran otomatis`)
let amount = Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)) + Number(digit())
let pay = await qrisDinamis(`${amount}`, "./payqris.jpg")
                let time = Date.now() + toMs(global.batas_waktu_pay_topup);
                let expirationTime = new Date(time);
                let timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
                let currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
                let expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
                let hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
                let minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
                let formattedTime = `${hours}:${minutes}`
                await sleep(2000)
let reffID = require("crypto").randomBytes(5).toString("hex").toUpperCase()
let Layanan = listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
   let har = Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan))
let pajakNy = amount - har
var qr_text =`━━[ *PEMBAYARAN OTOMATIS* ]━━

*▪ ID Produk:* ${q}
*▪ Name Layangan:* ${Layanan}
*▪  Harga:* Rp${toRupiah(Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)))}
*▪ Pajak Pay:* Rp${toRupiah(Number(pajakNy))}
*▪ Total Pembayaran:* Rp${toRupiah(amount)}
*▪ Batas Waktu:* ${timeLeft} Menit
*▪ Expired:* ${formattedTime} WIB

_Setelah anda melakukan pembayaran, Tahap selanjutnya adalah anda disuruh memasukan input No/Id_`
let payy = await ramz.sendMessage(from, { image: fs.readFileSync(pay), caption: qr_text }, { quoted: msg })

var object_buy = {
	session: "pembayaran",
number: sender,
result: "",
pay: "yes",
exp: time,
data: {
target: "",
code: q,
idtopup: "",
id: reffID,
price: Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)),
layanan: listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
}
}
fs.writeFile(topupPath + sender.split("@")[0] + ".json", JSON.stringify(object_buy, null, 3), () => {
  var intervals = setInterval(async function () {
    if (object_buy.session === "pembayaran") {
     
try {
    
      if (Date.now() >= object_buy.exp) {
        await ramz.sendMessage(from, { delete: payy.key });
        reply("Pembayaran Telah melewati batas waktu");
        fs.unlinkSync(topupPath + sender.split("@")[0] + ".json");
        clearInterval(intervals);
        return;
      }
  const ok = new OrderKuota(global.usn, global.token);
                        let response = await ok.getQRISHistory("qris_history");
                        let results = response?.qris_history?.results || [];

                        const toleransi = 0;
                        const amountInt = parseInt(amount); // 49321

                        let result = results.find(x => {
                            let kreditClean = Number(x.kredit.replace('.', '')); // "49.321" → 49321
                            return Math.abs(kreditClean - amountInt) <= toleransi;
                        });

                        console.log("Ditemukan:", result);
if (result) {
        

        await ramz.sendMessage(from, { delete: payy.key });
     if (q.toUpperCase().includes("ML")) {
   reply(`*[ PEMBAYARAN BERHASIL ]*

Silahkan ketik id & zone anda\n
Gabungkan keduanya tanpa ada karakter lain
Contoh :
733383273(8294)❌
7333832738294✅`);
} else {
	reply(`*[ PEMBAYARAN BERHASIL ]*

Silahkan masukan Id / nomor anda`)
	}
        await sleep(1000);
        object_buy.session = "target";
        fs.writeFileSync(topupPath + sender.split("@")[0] + ".json", JSON.stringify(object_buy, null, 3));
        clearInterval(intervals); // Jangan lupa clear interval setelah pembayaran berhasil
      }
    } catch (error) {
      reply("Ada kendala, pesanan dibatalkan\nSilahkan untuk melakukan topup kembali");
    await ramz.sendMessage(from, { delete: payy.key });
  console.log("---Eror--:", error);
      fs.unlinkSync(topupPath + sender.split("@")[0] + ".json");
      clearInterval(intervals);
      return;
    }
    }
  }, 13000);
  
})
                  } else {
let reffID = require("crypto").randomBytes(5).toString("hex").toUpperCase()
var object_buy = {
	session: "target",
number: sender,
pay: "no",
result: "",
data: {
target: "",
code: q,
idtopup: "",
id: reffID,
price: Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)),
layanan: listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
}
}
fs.writeFile(topupPath + sender.split("@")[0] + ".json", JSON.stringify(object_buy, null, 3), () => {
if (q.toUpperCase().includes("ML")) {
   reply(`Silahkan ketik id & zone anda\n
Gabungkan keduanya tanpa ada karakter lain
Contoh :
733383273(8294)❌
7333832738294✅`);
} else {
	reply(`*[ PEMBAYARAN BERHASIL ]*
	
	Silahkan masukan Id / nomor anda`)
	}
})
}

})
} else {
reply(`Kamu sedang melakukan topup, mohong tunggu sampai proses topup selesai atau ketik .cansel untuk membatalkan Transaksi topup `)
}
}
break
case 'topup2':{
if (!q) return reply(`Ex: ${prefix+command} kodeproduk no/id\n\nContoh: ${prefix+command} DML3 123456781234\n\nUntuk mendapatkan kode produk ketik *${prefix}pricelist *\n\n_NOTE: UNTUK TOPUP DIAMOND ML ID DENGAN ZONE DIGABUNG, JANGAN DIKASIH SPASI MAUPUN TANDA KURUNG Contoh: 1846795042936_`)
if (!q.split(" ")[1]) return reply(`Ex: ${prefix+command} kodeproduk no/id\n\nContoh: ${prefix+command} DML3 123456781234\n\nNote: Harap pastikan nomornya benar\n\nUntuk mendapatkan kode produk ketik *${prefix}pricelist *`)
if (!fs.existsSync(topupPath + sender.split("@")[0] + ".json")) {
let kode = q.split(" ")[0]
let target = q.split(" ")[1]
let reffID = require("crypto").randomBytes(5).toString("hex").toUpperCase()
axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
.then(async ress => {
	   if (!Array.isArray(ress)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let listproduk
for (let x of ress) {
if (x.kode == q.split(" ")[0]) {
listproduk = x ? x : false
}
}
if (!listproduk) return reply(`_Code produk *${q.split(" ")[0]}* Tidak sesuai_`)
let kntungan = (untung / 100) * listproduk.harga.replace(/[^0-9]/g, '')
if (cekSaldo(sender, db_saldo) < Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan))) {
 reply(`saldo anda kurang dari Rp${toRupiah(Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)))}\nBot akan mengirim pembayaran otomatis`)
let amount = Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)) + Number(digit())
let pay = await qrisDinamis(`${amount}`, "./payqris.jpg")

                let time = Date.now() + toMs(global.batas_waktu_pay_topup);
                let expirationTime = new Date(time);
                let timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
                let currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
                let expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
                let hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
                let minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
                let formattedTime = `${hours}:${minutes}`

                await sleep(2000)
let reffID = require("crypto").randomBytes(5).toString("hex").toUpperCase()
let Layanan = listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
   let har = Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan))
let pajakNy = amount - har
var qr_text =`━━[ *PEMBAYARAN OTOMATIS* ]━━

*▪ ID Produk:* ${q}
*▪ Name Layangan:* ${Layanan}
*▪  Harga:* Rp${toRupiah(Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)))}
*▪ Pajak Pay:* Rp${toRupiah(Number(pajakNy))}
*▪ Total Pembayaran:* Rp${toRupiah(amount)}
*▪ Batas Waktu:* ${timeLeft} Menit
*▪ Expired:* ${formattedTime} WIB

_Setelah anda melakukan pembayaran, Tahap selanjutnya adalah anda disuruh memasukan input No/Id_`
let payy = await ramz.sendMessage(from, { image: fs.readFileSync(pay), caption: qr_text }, { quoted: msg })
let statusPay = false;
while (!statusPay) {
                  await sleep(12000)
                  if (Date.now() >= time) {
                    statusPay = true
await ramz.sendMessage(from, { delete: payy.key });
        reply("Pembayaran Telah melewati batas waktu");
                  }
                  try {
                  
      const ok = new OrderKuota(global.usn, global.token);
                        let response = await ok.getQRISHistory("qris_history");
                        let results = response?.qris_history?.results || [];

                        const toleransi = 0;
                        const amountInt = parseInt(amount); // 49321

                        let result = results.find(x => {
                            let kreditClean = Number(x.kredit.replace('.', '')); // "49.321" → 49321
                            return Math.abs(kreditClean - amountInt) <= toleransi;
                        });

                        console.log("Ditemukan:", result);
if (result) {
        statusPay = true
        
        await ramz.sendMessage(from, { delete: payy.key });
fetch(`https://b2b.okeconnect.com/trx-v2?product=${kode}&dest=${target}&refID=${reffID}&memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}`, requestOptions)
  .then(response => response.json())
.then(res => {
	console.log(res)
   
	let persen = (untung / 100) * listproduk.harga.replace(/[^0-9]/g, '')
var object_buy = {
number: sender,
result: res.status,
data: {
idtopup: "",
code: kode,
target: target,
id: reffID,
price: Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)),
layanan: listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
}
}
fs.writeFile(topupPath + sender.split("@")[0] + ".json", JSON.stringify(object_buy, null, 3), () => {
reply(`*「 BERHASIL DI PROSES 」*\n\nYeayy, pesanan anda telah di proses oleh bot silahkan tunggu sejenak`)
var intervals = setInterval(function() {
var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};

fetch(`https://b2b.okeconnect.com/trx-v2?memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}&product=${object_buy.data.code}&dest=${object_buy.data.target}&refID=${object_buy.data.id}`, requestOptions)
.then(responsep => responsep.json())
.then(async resss => {
console.log(resss); // For Debugging
console.log(color("[TRANSAKSI]", "green"), `-> ${sender}`) // For Debugging
if (resss.status === "SUKSES") {
  generateImage(`${global.namaStore}`, `${object_buy.data.id}`, `${object_buy.data.layanan}`, `${resss.sn}`);
  await sleep(2500)
ramz.sendMessage(from, { image: fs.readFileSync(`./gambar/invoice.jpg`), caption: `*「  TOPUP SUKSES  」*\n*⌬ Status:* Suksess\n*⌬ ID Order:* ${object_buy.data.id}\n*⌬ Layanan:* ${object_buy.data.layanan}\n*⌬ Nomor Tujuan:* ${object_buy.data.target}\n*⌬ Price:* Rp${toRupiah(object_buy.data.price)}\n\n*⌬ SN:*\n${resss.sn}\n\n_Terimakasih kak sudah order.️_`}, {quoted: msg})
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
clearInterval(intervals);
return;
} else if (resss.status === "GAGAL") {
console.log(resss)
addSaldo(sender, object_buy.data.price, db_saldo)
reply(`❌Pesanan dibatalkan!\nSaldo anda otomatis bertambah silahkan topup ulang`)
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
clearInterval(intervals);
return;
} 
})
}, 5500)
})
})
}
} catch (error) {
      reply("Ada kendala, pesanan dibatalkan\nSilahkan untuk melakukan topup kembali");
    await ramz.sendMessage(from, { delete: payy.key });
  console.log("---Eror--:", error);
      statusPay = true
      return;
    }
    }
    } else { 
fetch(`https://b2b.okeconnect.com/trx-v2?product=${kode}&dest=${target}&refID=${reffID}&memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}`, requestOptions)
  .then(response => response.json())
.then(async res => {
	
	console.log(res)
    if (res.status === "GAGAL") {
return reply(`GAGAL.. Silahkan hubungi owner jika ada kendala`)
}
await sleep(3000)
	let persen = (untung / 100) * listproduk.harga.replace(/[^0-9]/g, '')

var object_buy = {
number: sender,
result: res.status,
data: {
idtopup: "",
code: kode,
target: target,
id: reffID,
price: Number(listproduk.harga.replace(/[^0-9]/g, '')) + Number(Math.ceil(kntungan)),
layanan: listproduk.keterangan.includes('H2H') 
                            ? listproduk.keterangan.replace('Customer H2H ', '') 
                            : listproduk.keterangan.replace('Customer ', '')
}
}
fs.writeFile(topupPath + sender.split("@")[0] + ".json", JSON.stringify(object_buy, null, 3), () => {
reply(`*「 BERHASIL DI PROSES 」*\n\nYeayy, pesanan anda telah di proses oleh bot silahkan tunggu sejenak`)
var intervals = setInterval(function() {
var requestOptions = {
  method: 'GET',
  redirect: 'follow'
};

fetch(`https://b2b.okeconnect.com/trx-v2?memberID=${idOrkut}&pin=${pinOrkut}&password=${pwOrkut}&product=${object_buy.data.code}&dest=${object_buy.data.target}&refID=${object_buy.data.id}`, requestOptions)
.then(responsep => responsep.json())
.then(async resss => {
console.log(resss); // For Debugging
console.log(color("[TRANSAKSI]", "green"), `-> ${sender}`) // For Debugging
if (resss.status === "SUKSES") {
  generateImage(`${global.namaStore}`, `${object_buy.data.id}`, `${object_buy.data.layanan}`, `${resss.sn}`);
  await sleep(2500)
ramz.sendMessage(from, { image: fs.readFileSync(`./gambar/invoice.jpg`), caption: `*「  TOPUP SUKSES  」*\n*⌬ Status:* Suksess\n*⌬ ID Order:* ${object_buy.data.id}\n*⌬ Layanan:* ${object_buy.data.layanan}\n*⌬ Nomor Tujuan:* ${object_buy.data.target}\n*⌬ Price:* Rp${toRupiah(object_buy.data.price)}\n\n*⌬ SN:*\n${resss.sn}\n\n_Terimakasih kak sudah order.️_`}, {quoted: msg})
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
clearInterval(intervals);
return;
} else if (resss.status === "GAGAL") {
console.log(resss)
addSaldo(sender, object_buy.data.price, db_saldo)
reply(`❌Pesanan dibatalkan!\nSaldo anda otomatis bertambah silahkan topup ulang`)
fs.unlinkSync(topupPath + sender.split("@")[0] + ".json")
clearInterval(intervals);
return;
} 
})
}, 5500)
})
})
}
})
} else {
reply(`Kamu sedang melakukan topup, mohong tunggu sampai proses topup selesai atau ketik .cansel untuk membatalkan Transaksi topup `)
}
}
break
case 'cansel':{
	if (!fs.existsSync(topupPath + sender.split("@")[0] + ".json")) return reply('Kamu sedang tidak melakukan topup')
            ramz.sendMessage(from,
{text: `Apakah anda ingin membatalkan Transaksi? pilih button dibawah`,
buttonText: "Tekan Disini",
sections: [{title: "Pilih iya atau tidak",
rows: [
{title: "Tidak", rowId: "ramagangeng", description: "Lanjut untuk Melanjutkan Transaksi"},
{title: "Iya", rowId: "batal", description: "Batal Untuk membatalkan Transaksi"}]}
]})
            }
            break
case 'pricelist':{
	if (!isGroup) {
const sections = [
{title: "𝗧𝗼𝗽𝘂𝗽 𝗚𝗮𝗺𝗲",
rows: [
{title: "Free fire", rowId: prefix+"ff", description: "list harga Topup Free Fire"},
{title: "Pubg Mobile", rowId: prefix+"pubg", description: "list harga Topup Pubg Mobile"},
{title: "Mobile legends", rowId: prefix+"ml", description: "list harga Topup Mobile legends"},
{title: "Call of Duty MOBILE", rowId: prefix+"cod", description: "list harga Topup COD Mobile"},
{title: "Super Sus", rowId: prefix+"supersus", description: "list harga Topup Super Sus"},
{title: "Stumble Guys", rowId: prefix+"stumble", description: "list harga Topup Stumble"},
{title: "Sausage Man", rowId: prefix+"sausage", description: "list harga Topup Sausage Man"},
{title: "Point blank", rowId: prefix+"pb", description: "list harga Topup Point Blank"},
{title: "Honor Of Kings", rowId: prefix+"hok", description: "list harga Topup Honor Of Kings"},
{title: "Garena Undawn", rowId: prefix+"undawn", description: "list harga Topup Garena Undawn"},
{title: "Valorant", rowId: prefix+"valorant", description: "list harga Topup Valorant"},
{title: "Arena Breakout", rowId: prefix+"ab", description: "list harga Topup Arena Breakpout"},
]},
{title: "𝗦𝗮𝗹𝗱𝗼 𝗘-𝘄𝗮𝗹𝗹𝗲𝘁",
rows: [
{title: "Dana", rowId: prefix+"dana", description: "list produk Saldo Dana"},
{title: "Gopay", rowId: prefix+"gopay", description: "list harga Saldo Gopay"},
{title: "Ovo", rowId: prefix+"ovo", description: "list harga Saldo Ovo"},
{title: "Shopeepay", rowId: prefix+"shopeepay", description: "list harga Saldo Shopeepay"},
{title: "LinkAja", rowId: prefix+"linkaja", description: "list harga Saldo LinkAja"},
{title: "Grab", rowId: prefix+"grab", description: "list harga Saldo Grab"},
{title: "i-Saku", rowId: prefix+"isaku", description: "list harga Saldo i-Saku"},
]},
{title: "𝗞𝘂𝗼𝘁𝗮 𝗜𝗻𝘁𝗲𝗿𝗻𝗲𝘁",
rows: [
{title: "Smartfren", rowId: prefix+"Smartfren", description: "list produk Kuota Smartfren"},
{title: "Telkomsel", rowId: prefix+"Telkomsel", description: "list produk Kouta Telkomsel"},
{title: "Indosat", rowId: prefix+"Indosat", description: "list produk Kouta Indosat"},
{title: "Axis", rowId: prefix+"Axis", description: "list produk Kouta Axis"},
{title: "Three", rowId: prefix+"Three", description: "list produk Kouta Three"},
]},
{title: "𝗣𝘂𝗹𝘀𝗮 𝘁𝗿𝗮𝗻𝘀𝗳𝗲𝗿",
rows: [
{title: "Smartfren", rowId: prefix+"pul_smartfren", description: "list produk Pulsa Smartfren"},
{title: "Telkomsel", rowId: prefix+"pul_telkomsel", description: "list produk Pulsa Telkomsel"},
{title: "Indosat", rowId: prefix+"pul_indosat", description: "list produk Pulsa Indosat"},
{title: "Axis", rowId: prefix+"pul_axis", description: "list produk Pulsa Axis"},
{title: "Three", rowId: prefix+"pul_three", description: "list produk Pulsa Three"},
]},
{title: "𝗧𝗼𝗸𝗲𝗻 𝗹𝗶𝘀𝘁𝗿𝗶𝗸",
rows: [
{title: "PLN", rowId: prefix+"pln", description: "list produk Token Pln"},
]}
]
let isian = `*--List Layanan Topup Ppob--*

> Nikmati belajar otomatis dan murah, proses secepat kilat dengan 2 metode pembelian yaitu deposit & auto order`
const listMessage = {
text: isian,
buttonText: 'Tekan Disini',
sections
}
ramz.sendMessage(from, listMessage)
} else {
	let teks = `*BERIKUT LIST HARGA YANG TERSEDIA📝*

_Silahkan Pilih layanan yang tersedia
dengan mengetik Arahan dibawah ini_

━[ *VOUCHER GAME🎮* ]━
KETIK *ml* LIST HARGA TOPUP ML
KETIK *ff* LIST HARGA TOPUP FF
KETIK *pubg* LIST HARGA TOPUP PUBG
KETIK *cod* LIST HARGA TOPUP COD
KETIK *supersus* LIST HARGA TOPUP SUPERSUS 
KETIK *stumble* LIST HARGA TOPUP STUMBLE GUYS 
KETIK *pb* LIST HARGA TOPUP POINT BLANK 
KETIK *hok* LIST HARGA TOPUP HONOR OF KINGS
KETIK *sausage* LIST HARGA TOPUP SAUSAGE MAN
KETIK *undawn* LIST HARGA TOPUP GARENA UNDAWN 
KETIK *valorant* LIST HARGA TOPUP VALORANT
KETIK *ab* LIST HARGA TOPUP ARENA BREAKOUT

━[ *TOKEN LISTRIK💡* ]━
KETIK *pln* LIST HARGA TOKEN PLN

━[ *TOPUP SALDO🏧* ]━
KETIK *dana* LIST HARGA SALDO DANA
KETIK *gopay* LIST HARGA SALDO GOPAY
KETIK *ovo* LIST HARGA SALDO OVO
KETIK *shopeepay* LIST HARGA SALDO SHOPEEPAY
KETIK *linkaja* LIST HARGA SALDO LINKAJA
KETIK *grab* LIST HARGA SALDO GRAB
KETIK *isaku* LIST HARGA SALDO ISAKU

━[ *KUOTA INTERNET🛜* ]━
KETIK *smartfren* LIST HARGA KUOTA SMARTFREN
KETIK *telkomsel* LIST HARGA KUOTA TELKOMSEL
KETIK *axis* LIST HARGA KUOTA AXIS
KETIK *indosat* LIST HARGA KUOTA INDOSAT
KETIK *three* LIST HARGA KUOTA THREE

━[ *PULSA TRANSFER📱* ]━
KETIK *pul_smartfren* LIST HARGA PULSA SMARTFREN
KETIK *pul_telkomsel* LIST HARGA PULSA TELKOMSEL
KETIK *pul_axis* LIST HARGA PULSA AXIS
KETIK *pul_indosat* LIST HARGA PULSA INDOSAT
KETIK *pul_three* LIST HARGA PULSA THREE`
reply(teks)
}
}
break
case 'setprofit':{
if (!isOwner) return reply(mess.OnlyOwner)
if (!q) return reply(`Gunakan dengan kata command: ${prefix+command} 20%\n\n_Text 20% bisa kalian ganti dengan seberapa besar Keuntungan Yg Akan anda Peroleh_`)
if (q.replace(/[^0-9]/g, '') < 1) return reply('Minimal 1%')
if (q.replace(/[^0-9]/g, '') > 99) return reply('Maksimal 99%')
untung = q.replace(/[^0-9]/g, '')
await reply(`Profit Anda telah distel menjadi ${q.replace(/[^0-9]/g, '')}%`)
}
break
case 'ml': {

   axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
            res.sort(regeXcomp);
            let listny = [];
            let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
            for (let i of res) {
                if (i.kode.startsWith('DML' || 'MLW')) {
                    const prof = (untung / 100) * Number(i.harga);
                    teks += `*Kode:* ${i.kode}\n*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}\n*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}\n*Status:* ${i.status == "1" ? "✅" : "❎"}\n\n`
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*\n\n> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;



case 'ff':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('FF')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
    case 'supersus':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('SUS')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'valorant':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('AVL')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
    case 'undawn':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('UW')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'pubg':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('PUBG')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'cod':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('COD')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'stumble':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.keterangan.includes('Stumble')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
    case 'ab':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.produk.includes('Arena Break')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
       
        }
    break;
    case 'sausage':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.produk.includes('Sausage')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
       
        }
    break;
case 'genshin':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.produk.includes('Genshin')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'pb':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.keterangan.includes('Cash') && i.kode.startsWith('PB')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            
              
           
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
        break
    case 'hok':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('HOK')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'pln':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA TOKEN PLN*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('PLN')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'dana': {
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
            res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
                if (i.kode.startsWith('D') && i.kategori == "DOMPET DIGITAL") {
                    const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'gopay':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA SALDO GOPAY*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('GJK')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
    case 'isaku':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA SALDO GOPAY*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('ISAKU')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
    
case 'grab':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*BERIKUT LIST HARGA TOPUP*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.keterangan.includes('GRAB')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;
case 'ovo':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA SALDO OVO*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('OVO')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'shopeepay':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA SALDO SHOPEEPAY*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('SHOPE')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'linkaja': {
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA SALDO LINKAJA*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kode.startsWith('LINK')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'smartfren':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA KUOTA SMARTFREN*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('KUOTA SMARTFREN')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'telkomsel':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA KUOTA TELKOMSEL*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('KUOTA TELKOMSEL')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'axis':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA KUOTA AXIS*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('KUOTA AXIS')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'indosat':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA KUOTA INDOSAT*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('KUOTA INDOSAT')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'three':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA KUOTA THREE*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('KUOTA TRI')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'pul_smartfren':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA PULSA SMARTFREN*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Smartfren')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'pul_telkomsel':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA PULSA TELKOMSEL*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Telkomsel')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'pul_axis':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA PULSA AXIS*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Axis')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'pul_indosat':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA PULSA INDOSAT*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
            	if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Indosat')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'pul_three':{
 axios.get('https://okeconnect.com/harga/json?id=905ccd028329b0a')
        .then(response => response.data)
        .then(res => {
            const regeXcomp = (a, b) => {
                const aPrice = Number(a.harga.replace(/[^0-9.-]+/g, ""));
                const bPrice = Number(b.harga.replace(/[^0-9.-]+/g, ""));
                return aPrice - bPrice;
            };
            if (!Array.isArray(res)) {
                return ramz.sendMessage(from, { text: "Data tidak valid atau kosong." });
            }
let teks = `*LIST HARGA PULSA THREE*\n\nIngin melakukan topup? ketik *${prefix}topup2*\n\n`
res.sort(regeXcomp);
            let listny = [];
            for (let i of res) {
if (i.kategori.includes('PULSA') && !i.kategori.includes('PULSA TRANSFER') && i.produk.includes('Three')) {
const prof = (untung / 100) * Number(i.harga);
                    listny.push({
                        title: i.keterangan.includes('H2H') 
                            ? i.keterangan.replace('Customer H2H ', '') 
                            : i.keterangan.replace('Customer ', ''),
                        rowId: `#topup ${i.kode}`,
                        description: `Harga: Rp${toRupiah(Number(i.harga) + Math.ceil(prof))} | Status ${i.status == "1" ? "✅" : "❎"}`
                    });
                    teks += `*Kode:* ${i.kode}
*Nama:* ${i.keterangan.includes('H2H') ? i.keterangan.replace('Customer H2H ', '') : i.keterangan.replace('Customer ', '')}
*Harga:* Rp${toRupiah(Number(i.harga) + Number(Math.ceil(prof)))}
*Status:* ${i.status == "1" ? "✅" : "❎"}

`
                }
            }
            const listMessage = {
                text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
                buttonText: "Tekan di sini",
                sections: [
                    {
                        title: "Price list 🛍️",
                        rows: listny
                    }
                ]
            };
            if (!isGroup) {
            ramz.sendMessage(from, listMessage);
         } else {   // jika di group
         reply(teks)
         }
        })
        .catch(error => {
            console.error(error);
            ramz.sendMessage(from, { text: "Terjadi kesalahan saat mengambil data. Silakan coba lagi nanti." });
        });
        }
    break;

case 'cekip': {
        if (!isOwner) return reply(mess.OnlyOwner)
        if (isGroup) return reply(`Tidak bisa didalam group`)
        fetch("https://api64.ipify.org?format=json")
          .then((response) => response.json())
          .then(res => {
            reply('Silahkan sambungkan IP (' + res.ip + ') tersebut ke provider.' + `\n\n*CARA:*\n- http://Okeconnect.com login ke web tersebut dengan akun order kouta anda\n- Klik baris tiga kiri atas - intergasi transaksi - transaksi via Ip\n- URL callback dan IP address kaliann masukan ip yang ada di atas\n- Masukan password dibawah\n- Lalu klik konfirmasi`)
          })
      }
        break
        case 'ceksaldo': {
    if (!isOwner) return reply(mess.OnlyOwner)
    if (isGroup) return reply(`Tidak bisa didalam group`)
    axios.get(`https://b2b.okeconnect.com/trx-v2/balance`, {
        params: {
            memberID: idOrkut,
            pin: pinOrkut,
            password: pwOrkut
        },
        timeout: 10000
    })
    .then(response => {
        const res = response.data
        console.log(res)
        if (res.status && res.status.toUpperCase().includes('GAGAL')) {
            return reply(`❌ Gagal cek saldo: ${res.message}`)
        }
        if (res.saldo) {
            return reply(`*SALDO ORDER KUOTA*\n\n*Sisa Saldo:* Rp${toRupiah(res.saldo)}`)
        }
        const saldo = res.message ? res.message.replace(/[^0-9]+/g, '') : "0"
        reply(`*SALDO ORDER KUOTA*\n\n*Sisa Saldo:* Rp${toRupiah(saldo)}`)
    })
    .catch(error => {
        console.error('Error fetching balance:', error.message || error)
        if (error.code === 'ECONNABORTED') {
            reply('⏳ Timeout: server tidak merespon, coba lagi nanti.')
        } else {
            reply('❌ Terjadi kesalahan saat mengecek saldo OrderKuota.')
        }
    })
}
break
     case 'addstock': case 'addstok': {
	if (!isOwner) return reply(mess.OnlyOwner)
    let args = q.split(","); // Pisahkan input dengan koma
    if (args.length < 5) {
        return reply(`Gunakan dengan cara:\n\n${command} *kodeProduk,username,password,email,deskripsi,username,password,email,deskripsi,username,password,email,deskripsi*\n\n_Contoh_\n\n#${command} netflix,ramagnz,rama123,rama123@gmail.com,Akun premium,userB,passB,userB@gmail.com,Akun VIP,userC,passC,userC@gmail.com,Akun Standard`);
    }
    let idProduk = args.shift().trim(); // Ambil kode produk (elemen pertama)
    let akunList = [];
    for (let i = 0; i < args.length; i += 4) {
        let username = args[i] ? args[i].trim() : "-";
        let password = args[i + 1] ? args[i + 1].trim() : "-";
        let email = args[i + 2] ? args[i + 2].trim() : "-";
        let deskripsi = args[i + 3] ? args[i + 3].trim() : "-";
        if (username === "-" || password === "-" || email === "-" || deskripsi === "-") {
            return reply(`Format salah! Pastikan setiap akun memiliki *username,password,email,deskripsi*`);
        }
        akunList.push({ username, password, email, deskripsi });
    }
  //  if (akunList.length === 0) return reply("Tidak ada akun yang valid untuk ditambahkan!");
    addAkunKeProduk(idProduk, akunList);
   // reply(`${akunList.length} akun berhasil ditambahkan ke produk "${idProduk}"`);
}
break;
case 'delproduk': {
	if (!isOwner) return reply(mess.OnlyOwner)
	if (!q) return reply(`Gunakan dengan cara ${command} kodeProduk`)
	delProduk(q)
	}
	break
	case 'rekap': {
    	if (!isOwner) return reply(mess.OnlyOwner)
    	rekapTransaksi()
    }
    break
    case "stock":
case "liststock":
case "stok":
case "liststok": {

  // --- Jika di GROUP, langsung tampilkan teks saja ---
  if (isGroup) {
    return tampilkanProduk(); 
  }

  // --- PRIVATE CHAT = Button List ---

  let database = readDatabase();

  if (database.produk.length === 0) {
    return ramz.sendMessage(from, { text: "❌ Tidak ada produk tersedia." });
  }

  // Sortir A-Z
  let sorted = database.produk.sort((a, b) =>
    a.nama.localeCompare(b.nama)
  );

  let listny = [];

sorted.forEach((produk, index) => {
  const nomor = index + 1;
  const namaKapital = produk.nama.toUpperCase();

  listny.push({
    title: `${nomor}. ${namaKapital}`,
    rowId: `#detail ${produk.id}`,
    description: `Harga Rp${produk.harga} | Stok ${produk.akun.length}`
  });
});

  const listMessage = {
    text: `*---Daftar Harga Produk---*

> Temukan produk terbaik untuk kebutuhan Anda! Pilih dengan mudah dan nikmati pengalaman berbelanja yang menyenangkan.`,
    buttonText: "Lihat Produk",
    sections: [
      {
        title: "Produk Tersedia",
        rows: listny
      }
    ]
  };

  return ramz.sendMessage(from, listMessage);
}
return;
break;
case "detail": {
    if (!q) return reply("Format salah!\nContoh: *#detail canva*");
    let id = q.toLowerCase().trim();
    let db = readDatabase();
    let produk = db.produk.find(p => p.id.toLowerCase() === id);
    if (!produk) {
        return reply("❌ Produk tidak ditemukan.");
    }
    // Format detail
    let teks = `
 *${produk.nama}*

> Harga : Rp${produk.harga}
> Kode  : ${produk.id}
> Stok  : ${produk.akun.length} akun
> Terjual : ${produk.terjual}
> Deskripsi:  ${produk.desk || "Tidak ada deskripsi."}

Pilih jumlah pembelian di tombol bawah 👇
`;

    // Generate tombol jumlah 1–10
    let rows = [];
    for (let i = 1; i <= 10; i++) {
        rows.push({
            title: `${i}`,
            rowId: `#buy ${produk.id},${i}`,
            description: `Klik untuk membeli Sejumlah ${i}`
        });
    }

    const listJumlah = {
        text: teks,
        buttonText: "Pilih Jumlah",
        sections: [
            {
                title: `Jumlah Pembelian untuk ${produk.nama}`,
                rows: rows
            }
        ]
    };

    return ramz.sendMessage(from, listJumlah);
}
break
	case 'setdeskproduk': case 'setdesk': {
		if (!isOwner) return reply(mess.OnlyOwner)
		var a1 = q.split(",")[0]
   var a2 = q.split(",")[1]
   if (!a1) return reply(`Gunakan dengan cara ${command} *kodeProduk,Text desk baru*`)
if (!a2) return reply(`Gunakan dengan cara ${command} *kodeProduk,Text desk baru*`)
editDeskripsiProduk(a1, a2)
}
break
case 'sethargaproduk': case 'setharga': {
	if (!isOwner) return reply(mess.OnlyOwner)
		var a1 = q.split(",")[0]
   var a2 = q.split(",")[1]
   if (!a1) return reply(`Gunakan dengan cara ${command} *kodeProduk,harga baru*`)
if (!a2) return reply(`Gunakan dengan cara ${command} *kodeProduk,harga baru*`)
if (isNaN(a2)) return reply("Input yang kedua adalah harga, Jadi Gunakan hanya angka")
editHargaProduk(a1, a2)
}
break
case 'setnamaproduk': case 'setnama': {
	if (!isOwner) return reply(mess.OnlyOwner)
		var a1 = q.split(",")[0]
   var a2 = q.split(",")[1]
   if (!a1) return reply(`Gunakan dengan cara ${command} *kodeProduk,Text Nama baru*`)
if (!a2) return reply(`Gunakan dengan cara ${command} *kodeProduk,Text Nama baru*`)
editNamaProduk(a1, a2)
}
break

case 'addproduk': {
	if (!isOwner) return reply(mess.OnlyOwner)
	var args1 = q.split(",")[0]
var args2 = q.split(",")[1]
var args3 = q.split(",")[2]
var args4 = q.split(",")[3]
if (!args1) return reply(`Gunakan dengan cara ${command} *kodeProduk,namaProduk,desk,harga*\n\n_Contoh_\n\n#${command} netflix,netflix premium,Akun ini blanlabla,15000`)
if (!args2) return reply(`Gunakan dengan cara ${command} *kodeProduk,namaProduk,desk,harga*\n\n_Contoh_\n\n#${command} netflix,netflix premium,Akun ini blanlabla,15000`)
if (!args3) return reply(`Gunakan dengan cara ${command} *kodeProduk,namaProduk,desk,harga*\n\n_Contoh_\n\n#${command} netflix,netflix premium,Akun ini blanlabla,15000`)
if (!args4) return reply(`Gunakan dengan cara ${command} *kodeProduk,namaProduk,desk,harga*\n\n_Contoh_\n\n#${command} netflix,netflix premium,Akun ini blanlabla,15000`)
if (!q.includes(",")) return reply(`Gunakan dengan cara ${command} *kodeProduk,namaProduk,desk,harga*\n\n_Contoh_\n\n#${command} netflix,netflix premium,Akun ini blanlabla,15000`)
if (isNaN(args4)) return reply("Input yang terakhir adalah harga, Jadi Gunakan hanya angka")
addProduk(args1, args2, args3, args4);
}
break


case 'buy': {
	if (!q) return reply(`Ex: ${prefix+command} kodeProduk,jumlah\n\nContoh: ${prefix+command} netflix,1\n\nUntuk mengecek stock yang tersedia silahkan ketik .stock`)
if (!q.split(",")[1]) return reply(`Ex: ${prefix+command} kodeProduk,jumlah\n\nContoh: ${prefix+command} netflix,1\n\nUntuk mengecek stock yang tersedia silahkan ketik .stock`)
let id = q.split(",")[0]
let jumlah = q.split(",")[1]
let reffID = require("crypto").randomBytes(5).toString("hex").toUpperCase()
let database = readDatabase();
  let produk = database.produk.find((p) => p.id === id);
  if (!produk) {
    reply(`Produk dengan ID *${id}* tidak ditemukan!`);
    return;
  }
  if (produk.akun.length < jumlah) {
    reply(`Stok akun tidak cukup! Tersedia: ${produk.akun.length}`);
    return;
  }
  reply(`Bot akan mengirim Pembayaran otomatis`)
  let amount = Number(produk.harga) * jumlah + Number(digit())
let pay = await qrisDinamis(`${amount}`, "./payqris.jpg")
let time = Date.now() + toMs("5m");
                let expirationTime = new Date(time);
                let timeLeft = Math.max(0, Math.floor((expirationTime - new Date()) / 60000));
                let currentTime = new Date(new Date().toLocaleString("en-US", { timeZone: "Asia/Jakarta" }));
                let expireTimeJakarta = new Date(currentTime.getTime() + timeLeft * 60000);
                let hours = expireTimeJakarta.getHours().toString().padStart(2, '0');
                let minutes = expireTimeJakarta.getMinutes().toString().padStart(2, '0');
                let formattedTime = `${hours}:${minutes}`
                let har = Number(produk.harga) * jumlah
let pajakNy = amount - har
                await sleep(2000)
                var qr_text =`━━[ *PEMBAYARAN OTOMATIS* ]━━

*⌬ Kode Produk:* ${id}
*⌬ Name Layangan:* ${produk.nama}
*⌬ Harga Per Item:* Rp${toRupiah(Number(produk.harga))}
*⌬ Jumlah Pembelian:* ${jumlah}
*⌬ Pajak Pay:* Rp${toRupiah(Number(pajakNy))}
*⌬ Total Pembayaran:* Rp${toRupiah(amount)}
*⌬ Batas Waktu:* ${timeLeft} Menit
*⌬ Expired:* ${formattedTime} WIB

Silahkan transfer ke qris sebelum melampaui batas waktu`
let payy = await ramz.sendMessage(from, { image: fs.readFileSync(pay), caption: qr_text }, { quoted: msg })
let statusPay = false;
let sudahProses = false; // ← tambahan anti double

while (!statusPay) {
                  await sleep(12000)
                  if (Date.now() >= time) {
                    statusPay = true
await ramz.sendMessage(from, { delete: payy.key });
        reply("Pembayaran Telah melewati batas waktu");
                  }
                  try {
                  
const ok = new OrderKuota(global.usn, global.token);
                        let response = await ok.getQRISHistory("qris_history");
                        let results = response?.qris_history?.results || [];

                        const toleransi = 0;
                        const amountInt = parseInt(amount); // 49321

                        let result = results.find(x => {
                            let kreditClean = Number(x.kredit.replace('.', '')); // "49.321" → 49321
                            return Math.abs(kreditClean - amountInt) <= toleransi;
                        });

                        console.log("Ditemukan:", result);
if (result) {
	if (sudahProses) return;   // ← ANTI DOUBLE
        sudahProses = true;       // ← Set flag supaya hanya 1x
        statusPay = true
        reply(`Maaf pembayaran berhasil akun akan segera dikirimkan ke nomor anda`)
        await ramz.sendMessage(from, { delete: payy.key });
        if (!database.terjual) database.terjual = [];

  let akunTerjual = produk.akun.splice(0, jumlah);
  akunTerjual.forEach((akun) => {
    database.terjual.push({
      produk: produk.nama,
      username: akun.username,
      password: akun.password,
      email: akun.email,
      deskripsi: akun.deskripsi,
      tanggalTerjual: new Date().toISOString(),
    });
  });

  let ter = Number(produk.terjual)
     let umj = Number(jumlah)
       produk.terjual = ter + umj
saveDatabase(database);

  let fileName = `./database/${id}_${Date.now()}.txt`;
  let fileContent = `「  TRANSAKSI SUKSES  」
*⌬ Status:* Suksess
*⌬ ID Order:* ${reffID}
*⌬ Jumlah:* ${jumlah}
*⌬ Produk:* ${produk.nama}


================================

〔 ACCOUNT 〕\n`

  akunTerjual.forEach((akun, index) => {
    fileContent += `Akun ${index + 1}:\n`;
    fileContent += `- Username: ${akun.username}\n`;
    fileContent += `- Password: ${akun.password}\n`;
    fileContent += `- Email: ${akun.email}\n`;
    fileContent += `- Deskripsi: ${akun.deskripsi}\n\n`;
  });

  fs.writeFileSync(fileName, fileContent);
  await sleep(1000)
  ramz.sendMessage(sender, {
                document: fs.readFileSync(fileName),
                mimetype: "text/plain",
                fileName: `ACCOUNT-${reffID}.txt`,
                caption: `「  TRANSAKSI SUKSES  」
Akun dikirim via file, Silahkan buka file txt diatas

*────「 DETAIL TRANSAKSI 」───*
*⌬ Status:* Suksess
*⌬ ID Order:* ${reffID}
*⌬ Jumlah:* ${jumlah}
*⌬ Produk:* ${produk.nama}
*⌬ Kode Produk:* ${id}
*⌬ Harga Per Item:* Rp${toRupiah(Number(produk.harga))}
*⌬ Jumlah Pembelian:* ${jumlah}
*⌬ Pajak Pay:* Rp${toRupiah(Number(pajakNy))}
*⌬ Total Pembayaran:* Rp${toRupiah(amount)}`
              }, { quoted: msg })
              await sleep(1000)
              ramz.sendMessage(ownerNumber, {
                text: `「  ADA YANG ORDER  」

*────「 DETAIL TRANSAKSI 」───*
*⌬ Number:* @${sender.split('@')[0]}
*⌬ ID Order:* ${reffID}
*⌬ Jumlah:* ${jumlah}
*⌬ Produk:* ${produk.nama}
*⌬ Total Pembayaran:* Rp${toRupiah(amount)}`,
mentions: [sender.split]})
              await sleep(1000)
              fs.unlinkSync(fileName)
        }
} catch (error) {
      reply("Ada kendala, pesanan dibatalkan\nSilahkan untuk melakukan pembelian kembali");
    await ramz.sendMessage(from, { delete: payy.key });
  console.log("---Eror--:", error);
      statusPay = true
      return;
    }
    }
    }
    break
    case 'getstock':
case 'getstok': {
  if (!isOwner) return reply(mess.OnlyOwner);

  const args = q.split(',');
  if (args.length < 3) {
    return reply(`Gunakan dengan cara:\n\n${command} *idProduk,jumlah,noWa*\nContoh:\n#${command} canva,1,62857912200179`);
  }

  const idProduk = args[0];
  const jumlah = parseInt(args[1]);
  const nomor = args[2].replace(/[^0-9]/g, '') + '@s.whatsapp.net';

  if (isNaN(jumlah) || jumlah <= 0) return reply("Jumlah harus berupa angka yang valid.");

  const database = readDatabase();
  const produk = database.produk.find(p => p.id === idProduk);
  if (!produk) return reply(`❌ Produk dengan ID "${idProduk}" tidak ditemukan.`);

  if (produk.akun.length < jumlah) {
    return reply(`Jumlah stok akun tidak cukup! Tersedia: ${produk.akun.length}`);
  }

  if (!database.terjual) database.terjual = [];

  let akunTerjual = produk.akun.splice(0, jumlah);
  akunTerjual.forEach((akun) => {
    database.terjual.push({
      produk: produk.nama,
      username: akun.username,
      password: akun.password,
      email: akun.email,
      deskripsi: akun.deskripsi,
      tanggalTerjual: new Date().toISOString(),
    });
  });

  let ter = Number(produk.terjual)
     let umj = Number(jumlah)
       produk.terjual = ter + umj
saveDatabase(database);

  let fileName = `./database/${id}_${Date.now()}.txt`;
  let fileContent = `「  TRANSAKSI SUKSES  」
*⌬ Status:* Suksess
*⌬ Jumlah:* ${jumlah}
*⌬ Produk:* ${produk.nama}


================================

〔 ACCOUNT 〕\n`

  akunTerjual.forEach((akun, index) => {
    fileContent += `Akun ${index + 1}:\n`;
    fileContent += `- Username: ${akun.username}\n`;
    fileContent += `- Password: ${akun.password}\n`;
    fileContent += `- Email: ${akun.email}\n`;
    fileContent += `- Deskripsi: ${akun.deskripsi}\n\n`;
  });

  fs.writeFileSync(fileName, fileContent);
  await sleep(1000)

  await ramz.sendMessage(nomor, {
    document: fs.readFileSync(fileName),
    mimetype: "text/plain",
    fileName: `ACCOUNT.txt`,
    caption: `「  TRANSAKSI SUKSES 」
Akun dikirim via file, silakan buka file txt di atas

*────「 DETAIL TRANSAKSI 」────*
*⌬ Status:* Sukses
*⌬ Jumlah:* ${jumlah}
*⌬ Produk:* ${produk.nama}
*⌬ Kode Produk:* ${idProduk}
*⌬ Harga Per Item:* Rp${toRupiah(Number(produk.harga))}
*⌬ Total Pembelian:* ${jumlah}`
  }, { quoted: msg });

  await sleep(1000);
  fs.unlinkSync(fileName);

  reply(`✅ Akun berhasil dikirim ke ${args[2]}`);
}
break;
case 'caraorder':
reply(`╭ 〔 *PANDUAN PEMESANAN* 〕 ╮
┊
1. Untuk melakukan *pemesanan*, silakan ketik: .buy {kode},{jumlah}

2. Untuk mengetahui *kode produk*, gunakan perintah *#stock*.

3. *Contoh pemesanan:* .buy canva,1

4. Setelah itu bot akan mengirim pembayaran otomatis

5. Lalu silahkan untuk melakukan pembayaran dan bot otomatis akan mengirim data akun anda
┊
╰──────────────╯`)
break

default:
if ((budy) && ["assalamu'alaikum", "Assalamu'alaikum", "Assalamualaikum", "assalamualaikum", "Assalammualaikum", "assalammualaikum", "Asalamualaikum", "asalamualaikum", "Asalamu'alaikum", " asalamu'alaikum"].includes(budy) && !isCmd) {
ramz.sendMessage(from, { text: `${pickRandom(["Wa'alaikumussalam","Wa'alaikumussalam Wb.","Wa'alaikumussalam Wr. Wb.","Wa'alaikumussalam Warahmatullahi Wabarakatuh"])}`})
}
if ((budy) && ["tes", "Tes", "TES", "Test", "test", "ping", "Ping"].includes(budy) && !isCmd) {
ramz.sendMessage(from, { text: `${runtime(process.uptime())}*⏰`})
}

}} catch (err) {
console.log(color('[ERROR]', 'red'), err)
const isGroup = msg.key.remoteJid.endsWith('@g.us')
const sender = isGroup ? (msg.key.participant ? msg.key.participant : msg.participant) : msg.key.remoteJid
const moment = require("moment-timezone");
const jam = moment.tz('asia/jakarta').format('HH:mm:ss')
const tanggal = moment().tz("Asia/Jakarta").format("ll")
let kon_erorr = {"tanggal": tanggal, "jam": jam, "error": err, "user": sender}
db_error.push(kon_erorr)
fs.writeFileSync('./database/error.json', JSON.stringify(db_error))
var errny =`*SERVER ERROR*
*Dari:* @${sender.split("@")[0]}
*Jam:* ${jam}
*Tanggal:* ${tanggal}
*Tercatat:* ${db_error.length}
*Type:* ${err}`
ramz.sendMessage(`${global.ownerNumber}`, {text:errny, mentions:[sender]})
}}